#include "tdaColaEntradaRestringida.h"


int Final = 0;
int FrenteInicio = 0;
int FrenteFinal = 0;
int* ColaDoble = 0;
int maximo = 0;