/**
 * @file principal.c
 * @author Eduardo Antonio Figueroa Salas (37186118@uaz.edu.mx)
 * @brief
 * @version 0.1
 * @date 2022-02-25
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "TADBidimensional.h"
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    TADcadena cad;
    TADcadena2 cad2;

    Menu(cad, cad2);

    return 0;
}
