#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "colasC.h"

void menu(void);
void realizar(int opcion);

int main(int argc, char *argv[]){
	int tamano;
	int opcion;
	puts("Ingrese el tamano de la cola");
	scanf("%d", &tamano);
	getchar();
	crear(tamano);
	do{
		menu();
		scanf("%d", &opcion);
		realizar(opcion);
		puts("");
	}while(opcion != 4);
}

void menu(void){
	puts("Menu de acciones");
	puts("1) Agregar");
	puts("2) Elminar");
	puts("3) Mostrar");
	puts("4) Salir");
}

void realizar(int opcion){
	switch(opcion){
		case 1:
			agregar();
			break;
		case 2:
			eliminar();
			break;
		case 3:
			mostrar();
			break;
		case 4:
			break;
		default:
			puts("Opcion invalida");
			puts("Intente nuevamente");
	}
}