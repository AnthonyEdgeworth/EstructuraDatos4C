#include "colasC.h"

int *cola;
int frente;
int final;
int TamM;

void crear(int tamano){
	cola = (int *)malloc(tamano * sizeof(int));
	for(int i = 0; i<tamano; i++){//cola inicializada a 0
		cola[i] = 0;
	}
	final = 0;
	frente = 0;
	TamM = tamano;
}

bool isEmpty(void){
	if(final == frente)
		return true;
	else
	return false;
	if(frente == TamM)
		frente = 0;
}

bool isFull(void){
	if(final - frente == TamM)
		return true;
	else{
		return false;
	}
	if(final == TamM)
		final = 0;
}

void agregar(void){
	int num;
	if(isFull()){
		puts("ADVERTENCIA: Espacio insuficiente");
		puts("Desbordamiento de pila");
	}
	else{
		puts("Ingrese el numero");
		scanf("%d", &num);
		getchar();
		cola[final++] = num;
	}
}

void eliminar(void){
	if(isEmpty()){
		puts("ADEVERTENCIA: No hay elementos");
		puts("Subdesbordamiento de pila");
	}
	else{
		cola[frente++] = 0;
	}
}

void mostrar(void){
	int i = frente;
	puts("La pila es: ");
	
	while(i > final){
		if(i<TamM){
			printf("%d", cola[i++]);
		}
		else{
			i = 0;
		}
	}
	while(i < final){
		printf("%d ", cola[i++]);
	}
}