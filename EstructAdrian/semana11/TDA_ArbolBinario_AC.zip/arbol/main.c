#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include "arbolBin.h"

void realizar(void);

int main(int argc, char *argv[]){
	
	realizar();
	
	return 0;
}

void realizar(void){
	
	arbol = cargarNodos(arbol);
	puts("Inorden:");
	inorden(arbol);
	puts("");
	puts("Preorden:");
	preorden(arbol);
	puts("");
	puts("Postorden:");
	postorden(arbol);
	puts("");
}