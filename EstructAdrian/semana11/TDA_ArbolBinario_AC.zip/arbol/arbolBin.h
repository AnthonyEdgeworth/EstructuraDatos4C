#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>

typedef struct nodoA{
	char info;
	struct nodoA *izq;
	struct nodoA *der;
}tiponodo;

typedef tiponodo *NodoA;
NodoA arbol;

NodoA nuevoNodo(NodoA,char,NodoA);
NodoA cargarNodos(NodoA);
void inorden(NodoA);
void preorden(NodoA);
void postorden(NodoA);