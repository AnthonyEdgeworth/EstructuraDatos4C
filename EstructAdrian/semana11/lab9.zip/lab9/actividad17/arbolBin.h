#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <stdbool.h>

typedef struct nodoA{
	char info;
	struct nodoA *izq;
	struct nodoA *der;
}tiponodo;

typedef tiponodo *NodoA;
NodoA arbol;

NodoA nuevoNodo(NodoA,char,NodoA);
NodoA cargarNodos(NodoA, char*, int*, bool);
void inorden(NodoA);
void preorden(NodoA);
void postorden(NodoA);
bool esOperador(char);