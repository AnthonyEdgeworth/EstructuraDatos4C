#include "arbolBin.h"

NodoA nuevoNodo(NodoA izq,char info ,NodoA der){
	NodoA q;
	q=(NodoA)malloc(sizeof(tiponodo));
	if(!q){
		printf("\nError al crear el nuevo nodo");
		return 0;
	}
	q->info=info;
	q->izq=izq;
	q->der=der;
	return q;
}

NodoA cargarNodos(NodoA ini, char* arreglo, int *contador, bool izquierda){
	if(arreglo[*contador] != '\0'){
	
		ini=nuevoNodo(NULL,arreglo[*contador],NULL);
		fflush(stdin);
		
		*contador = *contador + 1;
		
		if(izquierda == true){
			izquierda = esOperador(arreglo[*contador] - 1);
			fflush(stdin);
			ini->izq=cargarNodos(ini->izq, arreglo, contador, izquierda);
			fflush(stdin);
		} else {
			izquierda = esOperador(arreglo[*contador] - 1);
			fflush(stdin);
			ini->der=cargarNodos(ini->der, arreglo, contador, izquierda);
		}
	}
	return ini;
}

bool esOperador(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

void inorden(NodoA raiz){
	if(raiz !=NULL){
		inorden(raiz->izq);
		printf("%c",raiz->info);
		inorden(raiz->der);
	}
}

void preorden(NodoA raiz){
	if(raiz!=NULL){
		printf("%c",raiz->info);
		preorden(raiz->izq);
		preorden(raiz->der);	
	}
}

void postorden(NodoA raiz){
	if(raiz!=NULL){
		postorden(raiz->izq);
		postorden(raiz->der);
		printf("%c",raiz->info);
	}
}