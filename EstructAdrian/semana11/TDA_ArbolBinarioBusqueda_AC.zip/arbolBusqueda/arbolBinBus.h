#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>

typedef struct nodoA{
    int info;
    struct nodoA *izq;
    struct nodoA *der;
}tiponodo;
typedef tiponodo *NodoA;
NodoA arbol;
NodoA nuevoNodo(NodoA,int,NodoA );
NodoA cargarNodos(int,NodoA);

void inorden(NodoA );
void preorden (NodoA );
void postorden(NodoA );
int compara(int,int);
NodoA Busca(NodoA,int);
void InsertarDato(int);
NodoA elimina(NodoA,int);