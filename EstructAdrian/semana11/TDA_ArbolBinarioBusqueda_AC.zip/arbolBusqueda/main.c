#include<conio.h>
#include<stdlib.h>
#include<stdio.h>
#include "arbolBinBus.h"

#define NOCONTINUAR 2

void crearArbol(void);
void imprimir(void);
void buscar(void);
void acciones(void);
void eliminar(void);

int main(){

	crearArbol();	
	imprimir();	
	acciones();
}

void crearArbol(void){
	
	int opcion;
	int elem;
	
	puts("Creacion de nuevo arbol binario de busqueda\n");
	do{
		puts("Menu");
		puts("1) Agregar un nuevo elemento al arbol");
		puts("2) Terminar la insercion");
		scanf("%d", &opcion);
		getchar();
		
		if(opcion != 2){
			puts("Ingrese el elemento a agregar");
			scanf("%d", &elem);
			getchar();
			arbol = cargarNodos(elem,arbol);
		}
	}while(opcion != 2);
}

void imprimir(void){
	
	puts("Inorden:");
	inorden(arbol);
	puts("");
	
	puts("Preorden:");
	preorden(arbol);
	puts("");
	
	puts("Postorden:");
	postorden(arbol);
	puts("");
}

void buscar(void){
	int elem;
	NodoA temp;
	int continuar;
	
	do{
		puts("Ingrese el elemento a buscar:");
		scanf("%d",&elem);
		getchar();
		
		temp = Busca(arbol,elem);
		if (temp != NULL)
			printf("Se ha encontrado el elemento %d\n", temp->info);
		else
			puts("Elemento no encontrado");
			
		puts("Que desea hacer a continuacion?");
		puts("1) Buscar otro elemento");
		puts("2) Regresar al menu");
		scanf("%d",&continuar);
		getchar();
	} while (continuar != NOCONTINUAR);
}

void acciones(void){
	
	int PARAR = 3;
	int opcion;
	
	do{
		puts("Que desea hacer");
		puts("1) Buscar un elemento");
		puts("2) Eliminar un elemento");
		puts("3) Salir");
		scanf("%d", &opcion);
		getchar();
		
		switch(opcion){
			case 1:
				buscar();
				break;
			case 2:
				eliminar();
				break;
			case 3:
				break;
			default:
				puts("Opcion invalida, intente nuevamente");
		}
	} while (opcion != 3);
}

void eliminar(void){
	
	int PARAR = 2;
	int elem;
	int opcion;
	NodoA temp;
	
	do{
		puts("Ingrese el elemento a eliminar");
		scanf("%d",&elem);
		getchar();
		
		temp = Busca(arbol,elem);
		if(temp == NULL)
			puts("Elemento no encontrado, intente nuevamente");
		else{
			arbol = elimina(arbol, elem);
			puts("Elemento eliminado correctamente");
			
			puts("El nuevo arbol es:");
			imprimir();	
		}
		
		puts("Que desea hacer a continuacion?");
		puts("1) Eliminar otro elemento");
		puts("2) Regresar al menu");
		scanf("%d", &opcion);
		getchar();
	} while(opcion != PARAR);
}