#include "arbolBinBus.h"

NodoA nuevoNodo(NodoA izq,int inf,NodoA der){
	NodoA q;
		q=(NodoA)malloc(sizeof(tiponodo));
	if (!q){
		printf("\n Error al crear el nuevo nodo");
		exit(0);
	}
		q->info=inf;
		q->izq=izq;
		q->der=der;
	return q;
}

NodoA cargarNodos(int dato, NodoA ini){
	if (ini==NULL){
		ini=nuevoNodo(NULL,dato, NULL);
	}
	else if (compara(dato, ini->info)==-1){ //va al lado izquierdo
		ini->izq=cargarNodos(dato,ini->izq);
	}
	else if (compara(dato,ini->info)==1){//va al lado derecho
		ini->der=cargarNodos(dato, ini->der);
	}
return ini;
}
 
int compara(int a, int b){
	if (a<b)
		return -1;
	if (a>b)
		return 1;
	if (a==b)
		return 0;
}

void inorden(NodoA raiz){
	if (raiz!=NULL){
		inorden(raiz->izq);
		printf("%d ", raiz->info);
		inorden(raiz->der);
	}
}

void postorden(NodoA raiz){
	if (raiz!=NULL){
		postorden(raiz->izq);
		postorden(raiz->der);
		printf("%d ", raiz->info);
	}
}

void preorden(NodoA raiz){
	if(raiz!=NULL){
		printf("%d ", raiz->info);
		preorden(raiz->izq);
		preorden(raiz->der);
	}
}

NodoA Busca(NodoA raiz, int datoB){
	int bandera=0;
		if (raiz!=NULL){
				if (datoB==raiz->info){
					bandera=1;
				return raiz;
				}
				else{
		if (compara(datoB, raiz->info)==-1){
			raiz->izq=Busca(raiz->izq,datoB);
		}
		else if (compara(datoB, raiz->info)==1) {
			raiz->der=Busca(raiz->der,datoB);
			}
		}

	}	
}

NodoA elimina(NodoA raiz, int dato){
	
    if (raiz == NULL)
        return raiz;
    if (dato < raiz->info)
        raiz->izq = elimina(raiz->izq, dato);
    else if (dato > raiz->info)
        	raiz->der = elimina(raiz->der, dato);
    	else {
        	if (raiz->izq == NULL) {
        	    NodoA temp = raiz->der;
        	    raiz = NULL;
            	return temp;
        	}
        	else if (raiz->der == NULL) {
            	NodoA temp = raiz->izq;
            	raiz = NULL;
            	return temp;
        	}
        
			NodoA actual = raiz;

    		while (actual && actual->izq) {
      	  		actual = actual->izq;
    		}
   		
        	NodoA temp = actual;

        	raiz->info = temp->info;
        	raiz->der = elimina(raiz->der, temp->info);
    		}
    return raiz;
}