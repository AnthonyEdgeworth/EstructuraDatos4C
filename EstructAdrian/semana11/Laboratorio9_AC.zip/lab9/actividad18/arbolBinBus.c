#include "arbolBinBus.h"

NodoA nuevoNodo(NodoA izq,int inf,NodoA der, char *name){
	NodoA q;
		q=(NodoA)malloc(sizeof(tiponodo));
	if (!q){
		puts("Error al crear el nuevo nodo");
		exit(0);
	}
	q->edad = inf;
	strcpy(q->nombre, name);
	q->izq = izq;
	q->der = der;
	return q;
}

NodoA cargarNodos(int dato, char *name, NodoA ini){
	if (ini==NULL){
		ini=nuevoNodo(NULL,dato, NULL, name);
	}
	else if (compara(dato, ini->edad)==-1){
		ini->izq=cargarNodos(dato, name, ini->izq);
	}
	else if (compara(dato,ini->edad)==1){
		ini->der=cargarNodos(dato, name, ini->der);
	}
	return ini;
}
 
int compara(int a, int b){
	if (a<b)
		return -1;
	if (a>b)
		return 1;
	if (a==b)
		return 0;
}

void inorden(NodoA raiz){
	if (raiz!=NULL){
		inorden(raiz->izq);
		printf("Nombre: %s, Edad: %d; ", raiz->nombre, raiz->edad);
		inorden(raiz->der);
	}
}

void postorden(NodoA raiz){
	if (raiz!=NULL){
		postorden(raiz->izq);
		postorden(raiz->der);
		printf("Nombre: %s, Edad: %d; ", raiz->nombre, raiz->edad);
	}
}

void preorden(NodoA raiz){
	if(raiz!=NULL){
		printf("Nombre: %s, Edad: %d; ", raiz->nombre, raiz->edad);
		preorden(raiz->izq);
		preorden(raiz->der);
	}
}

NodoA Busca(NodoA raiz, int datoB){
	int bandera=0;
		if (raiz!=NULL){
				if (datoB==raiz->edad){
					bandera=1;
				return raiz;
				}
				else{
		if (compara(datoB, raiz->edad)==-1){
			raiz->izq=Busca(raiz->izq,datoB);
		}
		else if (compara(datoB, raiz->edad)==1) {
			raiz->der=Busca(raiz->der,datoB);
			}
		}

	}	
}

NodoA elimina(NodoA raiz, int dato){
	
    if (raiz == NULL)
        return raiz;
    if (dato < raiz->edad)
        raiz->izq = elimina(raiz->izq, dato);
    else if (dato > raiz->edad)
        	raiz->der = elimina(raiz->der, dato);
    	else {
        	if (raiz->izq == NULL) {
        	    NodoA temp = raiz->der;
        	    raiz = NULL;
            	return temp;
        	}
        	else if (raiz->der == NULL) {
            	NodoA temp = raiz->izq;
            	raiz = NULL;
            	return temp;
        	}
        
			NodoA actual = raiz;

    		while (actual && actual->izq) {
      	  		actual = actual->izq;
    		}
   		
        	NodoA temp = actual;

        	raiz->edad = temp->edad;
        	raiz->der = elimina(raiz->der, temp->edad);
    		}
    return raiz;
}