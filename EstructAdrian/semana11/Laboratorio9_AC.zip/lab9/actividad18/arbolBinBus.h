#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>

typedef struct nodoA{
    int edad;
    char nombre[50];
    struct nodoA *izq;
    struct nodoA *der;
}tiponodo;
typedef tiponodo *NodoA;
NodoA arbol;
NodoA nuevoNodo(NodoA, int, NodoA, char*);
NodoA cargarNodos(int, char*, NodoA);

void inorden(NodoA );
void preorden (NodoA );
void postorden(NodoA );
int compara(int,int);
NodoA Busca(NodoA,int);
void InsertarDato(int);
NodoA elimina(NodoA,int);