#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <stdbool.h>
#include "arbolBin.h"

#define mayus(x) x>64&&x<91 ? 1:0
#define minus(x) x>96&&x<123 ? 1:0

void realizar(void);
void imprimir(void);
void ingresar(void);

int tamano(char *cadena);
int prioridad(char actual, char pila);

char arrayI[20];
char arrayF[20];
int contador = 0;

int main(int argc, char *argv[]){
	
	ingresar();
	realizar();
	imprimir();
	
	return 0;
}

void realizar(void){
	
	arbol = cargarNodos(arbol, arrayF, &contador);
}

void ingresar(void){
	puts("Ingrese la notacion infija");
	gets(arrayI);
	
	//transformar de infija a prefija
	//esto no afecta a la impresion de notaciones, se usa porque el algoritmo para isercion al arbol solo funciona
	//con notacion prefija (el algoritmo es propio aunque es probable que ya exista)
	int tope = -1;
	int max;
	int pos = 0;
	char pila[20];
	char simbolo;
	
	max = tamano(arrayI) - 1;
	
	while(max>-1){
		simbolo = arrayI[max--];
		if(simbolo == ')'){
			pila[++tope] = simbolo;
		}
		else{
			if(simbolo == '('){
				while(pila[tope] != ')'){
					arrayF[pos++] = pila[tope--];
				}
				tope--;
			}
			else{
				if(mayus(simbolo) || minus(simbolo)){
					arrayF[pos++] = simbolo;
				}
				else{
					while(tope > -1 && prioridad(simbolo, pila[tope]) == 1){
						arrayF[pos++] = pila[tope--];
					}
					pila[++tope] = simbolo;
				}
			}
		}
	}
	
	while(tope>-1){
		arrayF[pos++] = pila[tope--];
	}
	
	//arrayF guarda los datos al reves
	int i = tamano(arrayF);
	int j = 0;
	char temporal[i];
	i--;
	while(i>-1){
		temporal[j++] = arrayF[i--];
	}
	i=0;
	while(temporal[i] != '\0'){
		arrayF[i] = temporal[i];
		i++;	
	}
}

void imprimir(void){
	
	puts("Estado del arbol:");
	puts("Inorden");
	inorden(arbol);
	puts("");
	puts("Preorden:");
	preorden(arbol);
	puts("");
	puts("Postorden:");
	postorden(arbol);
	puts("");
	
	puts("Conversiones:");
	puts("La notacion prefija es equivalente al recorrido preorden del arbol:");
	preorden(arbol);
	puts("");
	puts("La notacion posfija es equivalente al recorrido postorden del arbol:");
	postorden(arbol);
	puts("");
}

int tamano(char *cadena){
	int i = 0;
	while(cadena[i] != '\0'){
		i++;
	}
	return i;
}

int prioridad(char actual, char pila){
	//0 falso 1 verdadero
	if(actual == '^')
		return 0;
	if(pila == '^')
		return 1;
	if(actual == '/' || actual == '*')
		return 0;
	if(pila == '/' || pila == '*')
		return 1;
	return 0;
}