#include "arbolBin.h"

NodoA nuevoNodo(NodoA izq,char info ,NodoA der){
	NodoA q;
	q=(NodoA)malloc(sizeof(tiponodo));
	if(!q){
		printf("\nError al crear el nuevo nodo");
		return 0;
	}
	q->info=info;
	q->izq=izq;
	q->der=der;
	return q;
}

NodoA cargarNodos(NodoA ini, char* arreglo, int *contador){
	if(arreglo[*contador] != '\0'){
	
		ini=nuevoNodo(NULL,arreglo[*contador],NULL);
		fflush(stdin);
		
		*contador = *contador + 1;
		if(esOperador(arreglo[*contador - 1 ])){//si no es un operador no tiene hijos
			//aniadir elementos a la izq
			fflush(stdin);
			ini->izq=cargarNodos(ini->izq, arreglo, contador);
			fflush(stdin);
				
			//aniadir elementos a la der
			fflush(stdin);
			ini->der=cargarNodos(ini->der, arreglo, contador);
		}
			
			
	return ini;
	}
} 
                                                               
bool esOperador(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

void inorden(NodoA raiz){
	if(raiz !=NULL){
		inorden(raiz->izq);
		printf("%c",raiz->info);
		inorden(raiz->der);
	}
}

void preorden(NodoA raiz){
	if(raiz!=NULL){
		printf("%c",raiz->info);
		preorden(raiz->izq);
		preorden(raiz->der);	
	}
}

void postorden(NodoA raiz){
	if(raiz!=NULL){
		postorden(raiz->izq);
		postorden(raiz->der);
		printf("%c",raiz->info);	
	}
}