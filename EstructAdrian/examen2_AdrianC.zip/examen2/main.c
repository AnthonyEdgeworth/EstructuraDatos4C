#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include <time.h>
#include "InterListaEnlazada.h"

void menu(void);

int main(int argc, char *argv[]) {
	puts("Limite maximo de busqueda: 43 176");
	puts("");
	int x;
	puts("Ingrese el tamanno maximo del arreglo");
	scanf("%d", &x);
	getchar();
	
	for(int i = 0; i < x; i++){
		Lista = CrearFinal(Lista, i + 1);
	}
	
	puts("El programa buscara el ultimo numero");
	puts("Tiempo de ejecucion maximo");
	puts("");
	//No recursivo
	double time = 0.0;
	clock_t begin = clock();
	
	nodo n = BuscarX(Lista, x, 'C');//El tipo no importa
	printf("El numero encontrado es: %d\n", n->info);
	
	clock_t end = clock();
	
	time += (double)(end-begin) / CLOCKS_PER_SEC;
	
	printf("Tiempo no recursivo: %f\n", time);
	
	//Recursivo
	time = 0.0;
	begin = clock();
	
	n = BuscarXRecursivo(Lista.inicio, Lista.inicio, x, 'C');//El tipo no importa
	printf("El numero encontrado es: %d\n", n->info);
	
	end = clock();
	
	time += (double)(end-begin) / CLOCKS_PER_SEC;
	
	printf("Tiempo recursivo: %f\n", time);
	
	return 0;
}

/*#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include "InterListaEnlazada.h"

void menu(void);

int main(int argc, char *argv[]) {
	int opcion, men=0, elem, x;
	do{
	puts("Que desea hacer?");
	menu();
	scanf("%d", &opcion);
	getchar();
	switch(opcion){
	case 1:
		printf("Ingrese el elemnto\n");
		scanf("%d", &elem);
		getchar();
		Lista = CrearFinal(Lista, elem);
		break;
	case 2:
		printf("Ingrese el elemento\n");
		scanf("%d", &elem);
		getchar();
		Lista = CrearInicio(Lista, elem);
		break;
	case 3:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		puts("Ingrese el numero a agregar");
		scanf("%d", &elem);
		getchar();
		
		Lista = InsertarAntesX(Lista, elem, x);
		break;
	case 4:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		puts("Ingrese el numero a agregar");
		scanf("%d", &elem);
		getchar();
		
		Lista = InsertarDespuesX(Lista, elem, x);
		break;
	case 5:
		puts("Ingrese el numero a eliminar");
		scanf("%d", &elem);
		getchar();
		Lista = EliminarX(Lista,elem);
		break;
	case 6:
		Lista = EliminarInicio(Lista);
		break;
	case 7:
		Lista = EliminarFinal(Lista);
		break;
	case 8:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		
		Lista = EliminarAntesX(Lista, x);
		break;
	case 9:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		
		Lista = EliminarDespuesX(Lista, x);
		break;
	case 10:
		Lista = OrdenarLista(Lista);
		break;
	case 11:
		nodo n = BuscarX(4, Lista, 'A');
		nodo n = BuscarXRecursivo(Lista.inicio, Lista.inicio, 4, A);
		printf("Num: ", n->info);
	default:
		men=1;
	}
	Recorrer(Lista);
	puts("");
	}while(men==0);
	return 0;
}

void menu(void){
	puts("Opciones del examen");
	puts("[11] Buscar y comparar tiempos");
	
	puts("[1]Crear Final.");
	puts("[2]Crear Inicio.");
	puts("[3]Insertar antes de X.");
	puts("[4]Insertar despues de X");
	puts("[5]Eliminar X");
	puts("[6]Eliminar Inicio");
	puts("[7]Eliminar Final");
	puts("[8]Eliminar Antes de X");
	puts("[9]Eliminar Despues del X");
	puts("[10]Ordenar");
	puts("[12]Salir");
}*/