#include<conio.h>
#include<stdio.h>
#include<malloc.h>
#include<stdbool.h>
#include<ctype.h>
#include<stdlib.h>
//Describe las operaciones que puede realizar
//TDA GRAFOS
//Representación en memoria de un vértice de una grafo
//agregar nodo de lista sencilla
typedef struct Nodos{
	char info;
	struct Nodos *liga;
}tiponodols;

typedef struct nodoG{
   char info;
   int numAristasInc;
   int numAristaEntra;
   int numAristaSal;
   int pos;
}tiponodo;

typedef struct arista{
   int info;
   bool dirigida;
   struct nodoG *origen;
   struct nodoG *destino;
   int pos;
}tipoArista;

typedef tiponodo *NodoG;
typedef tipoArista *AristaG;
typedef tiponodols *nodo;
nodo p,q,t=NULL;
nodo Lista;
//conjuntos de vértices
NodoG *Grafos; //utilización de un arreglo (dinámico)
//conjunto de aristas
AristaG *Aristas;
int NumVertices;
int NumAristas;

NodoG *ArrayGrafos;
AristaG *ArrayAristas;
int **MatrizDistancia;
//operaciones crear grafo en memoria
NodoG* CargarGrafo(); //retorna el conjunto de vértices (arreglo)
void MuestraConjuntoVertice(NodoG*);
void MuestraGrafo(NodoG*);
//operaciones aristas
AristaG NuevaArista(int,NodoG,NodoG,bool,int );
AristaG* CrearAristas();
NodoG aVertice(char,NodoG *);
void MuestraConjuntoAristas(AristaG*);
void MatrizAdy(NodoG*,AristaG*);//genera y muestra
void ListaAdyacente(NodoG*,AristaG*);
void MatrizDistanciaF(NodoG* G,AristaG* Ag);
void CrearFinal(char Elem);
NodoG NuevoNodoG(char dato,int Ninc, int Nentra, int Nsal, int p);

int tam = 0;
char verticeName[30];
int verticeAI[30];
int verticeAE[30];
int verticeAS[30];

int tamA = 0;
int aristaTam[50];
char aristaO[50];
char aristaD[50];
int aristaDir[50];

//operaciones de lista enlazada para crear la ListaAdyacente
nodo nuevoNodoL(char inf,nodo liga){
	nodo q;
	q=(nodo)malloc(sizeof(tiponodols));
	if (!q){
		printf("\n Error al crear el nuevo nodo");
		exit(0);
	}
	q->info=inf;
	q->liga=liga;
	
	return q;
}
	
void CrearFinal(char Elem){
	nodo n;
	if (p==NULL) //ES el primer nodo
	{
		p=nuevoNodoL(Elem,NULL);
		t=p;
	}
	else{ //nodos subsecuentes
		n=nuevoNodoL(Elem,NULL);
		t->liga=n;
		t=n;
	}
}
	
nodo RecorrerUltimo(nodo lista){
	t=lista;
	while (lista!=NULL){
		t=lista;
		lista=lista->liga;
	}
	return t;
}

void Recorrer(nodo Lista){
	while (Lista!=NULL){
		printf("%c -> ",Lista->info);
		Lista=Lista->liga;
	}
}

NodoG NuevoNodoG(char dato,int Ninc, int Nentra, int Nsal, int p){
	NodoG n;
	n=(NodoG)malloc(sizeof(tiponodo));
	if(!n){
		printf("Error al crar vertice\n");
		exit(0);
	}
	n->info=dato;
	n->numAristasInc=Ninc;
	n->numAristaEntra=Nentra;
	n->numAristaSal=Nsal;
	n->pos=p;
	return n;
}
	
NodoG* CargarGrafo(){

	int i;
	NodoG * Grafos;
	
	Grafos=(NodoG*)malloc(tam * sizeof(tiponodo));
	
	for(i=0; i<tam; i++){
		Grafos[i]=NuevoNodoG(verticeName[i], verticeAI[i], verticeAE[i], verticeAS[i], i);
	}
	
	return Grafos;
}
	
void MuestraConjuntoVertice(NodoG* vg){
	int i;
	for(i=0; i<tam; i++){
		printf("Vertices = [%c] \n",vg[i]->info);
	}
}
	
AristaG NuevaArista(int dato, NodoG origen, NodoG destino, bool dirigida, int p){
	AristaG a;
	a=(AristaG)malloc(sizeof(tipoArista));
	if(!a){
		printf("\nError no se pudo crear la arista");
		return NULL;
	}
	a->info=dato;
	a->origen=origen;
	a->destino=destino;
	a->dirigida=dirigida;
	a->pos=p;
	return a;
}
	
AristaG* CrearAristas(){

	int i;
	bool dir;
	NodoG ori, dest;
	
	Aristas=(AristaG *)malloc(tamA * sizeof(tipoArista));
	for(i=0; i<tamA; i++){
		ori = aVertice(aristaO[i], ArrayGrafos);
		if(ori==NULL){
			printf("No existe el vertice origen\n");
			exit(0);
		}
		dest = aVertice(aristaD[i], ArrayGrafos);
		if(dest==NULL){
			printf("No existe el vertice destino\n");
			exit(0);
		}
		if(aristaDir[i] == 1)
			dir=true;
		else
			dir=false;
		
		Aristas[i]=NuevaArista(aristaTam[i], ori, dest, dir, i);
	}
	return Aristas;
}
	
NodoG aVertice(char v, NodoG *grafo){
	int i;
	if(grafo!=NULL){
		for(i=0; i<tam; i++){
			if(v==grafo[i]->info){
				return grafo[i];
			}
		}
	}
	return NULL;
}
	
void MuestraConjuntoAristas(AristaG *Ag){
	int i;
	printf("Nodo Origen ---------Arista---------- Nodo Destino\n");
	for(i=0; i<tamA;i++){
		if(Ag[i]->dirigida==false){
			printf("     (%c)     ----------%d---------     (%c)     \n", Ag[i]->origen->info,Ag[i]->info,Ag[i]->destino->info);
		}else if(Ag[i]->dirigida==true){
			printf("     (%c)     ----------%d---------->    (%c)     \n", Ag[i]->origen->info,Ag[i]->info,Ag[i]->destino->info);
		}
		printf("\n");
	}
}
	
void MatrizAdy(NodoG* G, AristaG* Ag){
	int i;
	int j;
	int **MatrizAdyacente;
	MatrizAdyacente=(int **)malloc(tam*sizeof(int));
	for(i=0;i<=tam;i++){
		MatrizAdyacente[i]=(int *)malloc(tam*sizeof(int));
	}
	for(i=0;i<=tam;i++){
		for(j=0;j<=tam;j++){
			MatrizAdyacente[i][j]=0;
		}
	}
	for(i=0; i<tam;i++){
		MatrizAdyacente[Ag[i]->origen->pos][Ag[i]->destino->pos]=1;
	}
	for(i=0; i<tam;i++){
		printf("  %d",i+1);
	}
	
	for(i=0; i<tam;i++){
		printf("\n%d ",i+1);
		for(j=0; j<tam;j++){
			printf("[%d] ",MatrizAdyacente[i][j]);
		}
	}
	
	/*MatrizDistancia=(int **)malloc(tam*sizeof(int));
	for(i=0;i<tam;i++){
		MatrizDistancia[i]=(int *)malloc(tam*sizeof(int));
	}
	for(i=0;i<tam;i++){
		for(j=0;j<tam;j++){
			if(i==j){
				MatrizDistancia[i][j]=0;
			}else{
				MatrizDistancia[i][j]=-1;
			}
		}
	}
	
	for(i=0; i<tamA;i++){
		MatrizDistancia[Ag[i]->origen->pos][Ag[i]->destino->pos]=Ag[i]->info;
	}
	
	for(i=0; i<tam;i++){
		printf("\n%d ",i+1);
		for(j=0; j<tam;j++){
			//printf("[%d]   ",MatrizDistancia[i][j]);
			if(MatrizDistancia[i][j] == -1 || MatrizDistancia[i][j] == 0)
				printf("[0]   ");
			else
				printf("[1]   ");
		}
	}
	printf("\n");*/
}
	
void ListaAdyacente(NodoG* G,AristaG* Ag){
	nodo *ListAdy;
	int i;
	ListAdy=(nodo **)malloc((tam)*sizeof(nodo));
	for(i=0; i<tam;i++){
		ListAdy[i]=nuevoNodoL(-1,NULL);
	}
	for(i=0; i<tamA;i++){
		if(ListAdy[Ag[i]->origen->pos]->info==-1){
			ListAdy[Ag[i]->origen->pos]->info=Ag[i]->origen->info;
		}
		Lista=ListAdy[Ag[i]->origen->pos];
		p=Lista;
		t=RecorrerUltimo(Lista);
		CrearFinal(Ag[i]->destino->info);
	}
	puts("\n");
	for(i=0; i<tam; i++){
		printf("ListAdy [%c]->",G[i]->info);
		Recorrer(ListAdy[i]->liga);
		printf("\n");
	}
}
	
void MatrizDistanciaF(NodoG* G,AristaG* Ag){
	int i;
	int j;
	MatrizDistancia=(int **)malloc(tam*sizeof(int));
	for(i=0;i<tam;i++){
		MatrizDistancia[i]=(int *)malloc(tam*sizeof(int));
	}
	for(i=0;i<tam;i++){
		for(j=0;j<tam;j++){
			if(i==j){
				MatrizDistancia[i][j]=0;
			}else{
				MatrizDistancia[i][j]=-1;
			}
		}
	}
	for(i=0; i<tamA;i++){
		MatrizDistancia[Ag[i]->origen->pos][Ag[i]->destino->pos]=Ag[i]->info;
	}
	printf("\n");
	for(i=0; i<tam;i++){
		printf("  %c",G[i]->info);
	}
	
	for(i=0; i<tam;i++){
		printf("\n%c ",G[i]->info);
		for(j=0; j<tam;j++){
			printf("[%d]   ",MatrizDistancia[i][j]);
		}
	}
	printf("\n");
}