#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include <ctype.h>

#include "InterGrafos.h"

FILE *archivoV;
FILE *archivoA;

void crearGrafos();
void obtenerInfo();

void crearVertices();
void crearAristas();
void adyacencia();
void distancia();

int main(){
	
	//abrir archivos
	archivoV = fopen("ConjuntoVerticesD2.txt" ,"r");
	archivoA = fopen("ConjuntoAristasD2.txt" ,"r");
	
	if(archivoV == NULL || archivoA == NULL){
		puts("Error en la apertura de archivos");
		puts("Para funcionar el nombre de los archivos no debe de ser modificado, y se deben de encontrar en la misma carpeta");
	}
	else{
		obtenerInfo();
		crearGrafos();
	}
	
	//cerrar archivos
	fclose(archivoV);
	fclose(archivoA);
}

void crearGrafos(){
	
	puts("---------- GRAFOS EN BASE A ARCHIVOS ----------\n");
	crearVertices();
	crearAristas();
	adyacencia();
	distancia();
}

void crearVertices(){
	
	ArrayGrafos=CargarGrafo();
	puts("Conjunto de vertices del grafo\n");
	MuestraConjuntoVertice(ArrayGrafos);//	
}

void crearAristas(){
	
	ArrayAristas=CrearAristas();
	puts("\nConjunto de aristas del grafo");
	MuestraConjuntoAristas(ArrayAristas);
}

void adyacencia(){

	ListaAdyacente(ArrayGrafos,ArrayAristas);	
	MatrizAdy(ArrayGrafos,ArrayAristas);
}

void distancia(){
	
	puts("\nMatriz de distancia");
	MatrizDistanciaF(ArrayGrafos,ArrayAristas);
	getchar();
}

void obtenerInfo(){
	
	int i = 0;
	
	//info vertices
	while(!feof(archivoV)) {
		fscanf(archivoV, "%c\n%d\n%d\n%d\n", &verticeName[i], &verticeAI[i], &verticeAE[i], &verticeAS[i]);
		i++;
		tam++;
	}
	
	//info aristas
	i = 0;
	
	while(!feof(archivoA)) {
		fscanf(archivoA, "%d\n%c\n%c\n%d\n", &aristaTam[i], &aristaO[i], &aristaD[i], &aristaDir[i]);//se elimina el 1 basura
		i++;
		tamA++;
	}
}