#include<conio.h>
#include<stdio.h>
#include<malloc.h>
#include<stdbool.h>
#include <ctype.h>
#include <math.h>

#define INF 10000000
#define MaxSize 50

int graph[MaxSize][MaxSize];  // MaxSize es el n�mero m�ximo de v�rtices
int dis[MaxSize];             // dis [i] es la distancia m�s corta desde el punto de origen al v�rtice i
int visit[MaxSize];            // visit [i] marca si se ha encontrado la ruta m�s corta del v�rtice i. visit [i] == 1 significa que se ha encontrado
int prevetrix[MaxSize];      // Punto de conducci�n delantero

void dij(int n)
{    
	int count = 0;          // recuento es el n�mero de v�rtices que han encontrado el camino m�s corto
	visit[0] = 1;    
	prevetrix[0] = 0;    
	count++;    
	
	for (int i = 1; i < n; i++)    // inicializaci�n
	{        
		dis[i] = graph[0][i];        
		prevetrix[i] = 0;    
	}    
	while (count < n)    
	{        
		int min = INF, target_index;        
		for (int i = 1; i < n; i++)        
		{            
			if (visit[i] == 0 && min > dis[i])         // Encuentra el v�rtice con la distancia m�s corta desde la fuente target_index
			{                
				min = dis[i];                
				target_index = i;            
			}        
		}        
		visit[target_index] = 1;        
		count++;        
		for (int i = 1; i < n; i++)        
		{            
			if (visit[i] == 0 && dis[target_index] + 
				graph[target_index][i] < dis[i])            //Actualizar
			{                
				dis[i] = dis[target_index] + graph[target_index][i];
				prevetrix[i] = target_index;            
			}        
		}    
	}
}
