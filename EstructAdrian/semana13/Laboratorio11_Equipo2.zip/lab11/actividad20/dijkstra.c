#include<conio.h>
#include<stdio.h>
#include<malloc.h>
#include<stdbool.h>
#include <ctype.h>
#include "dijkstra.h"

int main()
{    
	int n, m;    
	scanf("%d %d", &n, &m);    
	int a, b, w, path[n];    
	for (int i = 0; i < n; i++)    
	{        
		for (int j = 0; j < n; j++)        
		{            
			graph[i][j] = INF;        
		}    
	}    
	for (int i = 0; i < m; i++)    
	{        
		scanf("%d %d %d", &a, &b, &w);        
		graph[a][b] = w;    
	}     
	dij(n);    
	printf("\n\n");    
	for (int i = 1; i < n; i++)    
	{        
		if (dis[i] == INF)        
		{            
			printf("No hay una ruta m�s corta desde el v�rtice 0 al v�rticeb %d \n", i);        
		}        
		else        
		{            
			printf("La ruta m�s corta desde el v�rtice 0 al v�rtice %d es %d:", i,dis[i]);            
			int cur = i, index = 0;            
			path[index] = cur;            
			while (1)            
			{                
				path[index + 1] = prevetrix[path[index]];                
				if (path[index + 1] == 0)                    
					break;                
				index++;            
			}            
			for (int j = index + 1; j > 0; j--)            
			{                
				printf("%d->", path[j]);            
			}            
			printf("%d\n", path[0]);        
		}    
	}
}
