#include "InterGrafos.h"

int main(){
	printf("---------- TDA GRAFOS ----------\n\n");
	ArrayGrafos=CargarGrafo();
	printf("Conjunto de vertices del grafo\n");
	MuestraConjuntoVertice(ArrayGrafos);
	ArrayAristas=CrearAristas();
	printf("Conjunto de aristas del grafo\n");
	MuestraConjuntoAristas(ArrayAristas);
	MatrizAdy(ArrayGrafos,ArrayAristas);
	ListaAdyacente(ArrayGrafos,ArrayAristas);
	printf("Matriz de distancia");
	MatrizDistanciaF(ArrayGrafos,ArrayAristas);
	getchar();
}