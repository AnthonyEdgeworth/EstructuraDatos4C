#ifndef _InterGrafos
#define _InterGrafos
#include<conio.h>
#include<stdio.h>
#include<malloc.h>
#include<stdbool.h>
#include<ctype.h>
#include<stdlib.h>
//Describe las operaciones que puede realizar
//TDA GRAFOS
//Representación en memoria de un vértice de una grafo
//agregar nodo de lista sencilla
typedef struct Nodos{
	char info;
	struct Nodos *liga;
}tiponodols;

typedef struct nodoG{
   char info;
   int numAristasInc;
   int numAristaEntra;
   int numAristaSal;
   int pos;
}tiponodo;

typedef struct arista{
   int info;
   bool dirigida;
   struct nodoG *origen;
   struct nodoG *destino;
   int pos;
}tipoArista;

typedef tiponodo *NodoG;
typedef tipoArista *AristaG;
typedef tiponodols *nodo;
nodo p,q,t=NULL;
nodo Lista;
//conjuntos de vértices
NodoG *Grafos; //utilización de un arreglo (dinámico)
//conjunto de aristas
AristaG *Aristas;
int NumVertices;
int NumAristas;

NodoG *ArrayGrafos;
AristaG *ArrayAristas;
int **MatrizDistancia;
//operaciones crear grafo en memoria
NodoG* CargarGrafo(); //retorna el conjunto de vértices (arreglo)
void MuestraConjuntoVertice(NodoG*);
void MuestraGrafo(NodoG*);
//operaciones aristas
AristaG NuevaArista(int,NodoG,NodoG,bool,int );
AristaG* CrearAristas();
NodoG aVertice(char,NodoG *);
void MuestraConjuntoAristas(AristaG*);
void MatrizAdy(NodoG*,AristaG*);//genera y muestra
void ListaAdyacente(NodoG*,AristaG*);
void MatrizDistanciaF(NodoG* G,AristaG* Ag);
void CrearFinal(char Elem);
NodoG NuevoNodoG(char dato,int Ninc, int Nentra, int Nsal, int p);

//operaciones de lista enlazada para crear la ListaAdyacente
nodo nuevoNodoL(char inf,nodo liga){
	nodo q;
	q=(nodo)malloc(sizeof(tiponodols));
	if (!q){
		printf("\n Error al crear el nuevo nodo");
		exit(0);
	}
	q->info=inf;
	q->liga=liga;
	
	return q;
}
	
void CrearFinal(char Elem){
	nodo n;
	if (p==NULL) //ES el primer nodo
	{
		p=nuevoNodoL(Elem,NULL);
		t=p;
	}
	else{ //nodos subsecuentes
		n=nuevoNodoL(Elem,NULL);
		t->liga=n;
		t=n;
	}
}
	
nodo RecorrerUltimo(nodo lista){
	t=lista;
	while (lista!=NULL){
		t=lista;
		lista=lista->liga;
	}
	return t;
}

void Recorrer(nodo Lista){
	while (Lista!=NULL){
		printf("%c -> ",Lista->info);
		Lista=Lista->liga;
	}
}

NodoG NuevoNodoG(char dato,int Ninc, int Nentra, int Nsal, int p){
	NodoG n;
	n=(NodoG)malloc(sizeof(tiponodo));
	if(!n){
		printf("Error al crar vertice\n");
		exit(0);
	}
	n->info=dato;
	n->numAristasInc=Ninc;
	n->numAristaEntra=Nentra;
	n->numAristaSal=Nsal;
	n->pos=p;
	return n;
}
	
NodoG* CargarGrafo(){
	char dato;
	int i;
	int nInc=0, nEntra=0, nSal=0;
	NodoG * Grafos;
	printf("Cuantos vertices tiene el grafo?\n");
	scanf("%d",&NumVertices);
	fflush(stdin);
	
		Grafos=(NodoG*)malloc(NumVertices * sizeof(tiponodo));
		for(i=0; i<NumVertices; i++){
			fflush(stdin);
			printf("\nDame la informacion del vertice %d\n",i+1);
			scanf("%c",&dato);
			fflush(stdin);
			printf("Dame el num de las aristas incidentes del vertice %d\n",i+1);
			scanf("%d",&nInc);
			printf("Dame el num de las aristas entrantes del vertice %d\n",i+1);
			scanf("%d",&nEntra);
			printf("Dame el num de las aristas salientes del vertice %d\n",i+1);
			scanf("%d",&nSal);
			Grafos[i]=NuevoNodoG(dato,nInc,nEntra,nSal,i);
		}
		getchar();
		return Grafos;
}
	
void MuestraConjuntoVertice(NodoG* vg){
	int i;
	for(i=0; i<NumVertices;i++){
		printf("Vertices = [%c] \n",vg[i]->info);
	}
}
	
AristaG NuevaArista(int dato, NodoG origen, NodoG destino, bool dirigida, int p){
	AristaG a;
	a=(AristaG)malloc(sizeof(tipoArista));
	if(!a){
		printf("\nError no se pudo crear la arista");
		return NULL;
	}
	a->info=dato;
	a->origen=origen;
	a->destino=destino;
	a->dirigida=dirigida;
	a->pos=p;
	return a;
}
	
AristaG* CrearAristas(){
	int dato;
	int i;
	char o,d;
	bool dir;
	char opc;
	NodoG ori, dest;
	printf("Cuantas aristas tiene el grafo\n");
	scanf("%d",&NumAristas);
	fflush(stdin);
	Aristas=(AristaG *)malloc(NumAristas * sizeof(tipoArista));
	for(i=0; i<NumAristas;i++){
		fflush(stdin);
		printf("\nDame el nombre o peso de la arista\n");
		scanf("%d",&dato);
		fflush(stdin);
		printf("Dame el nodo origen\n");
		scanf("%c",&o);
		fflush(stdin);
		printf("Dame el nodo destino\n");
		scanf("%c",&d);
		fflush(stdin);
		ori=aVertice(o,ArrayGrafos);
		if(ori==NULL){
			printf("No existe el vertice origen\n");
			exit(0);
		}
		dest=aVertice(d,ArrayGrafos);
		if(dest==NULL){
			printf("No existe el vertice destino\n");
			exit(0);
		}
		printf("La arista es dirigida (S) o no dirigida (N) \n");
		scanf("%c",&opc);
		if(toupper(opc)=='S'){
			dir=true;
		}else if(toupper(opc)=='N'){
			dir=false;
		}
		Aristas[i]=NuevaArista(dato,ori,dest,dir,i);
	}
	return Aristas;
}
	
NodoG aVertice(char v, NodoG *grafo){
	int i;
	if(grafo!=NULL){
		for(i=0; i<NumVertices;i++){
			if(v==grafo[i]->info){
				return grafo[i];
			}
		}
	}
	return NULL;
}
	
void MuestraConjuntoAristas(AristaG *Ag){
	int i;
	printf("Nodo Origen ---------Arista---------- Nodo Destino\n");
	for(i=0; i<NumAristas;i++){
		if(Ag[i]->dirigida==false){
			printf("     (%c)     ----------%d---------     (%c)     \n", Ag[i]->origen->info,Ag[i]->info,Ag[i]->destino->info);
		}else if(Ag[i]->dirigida==true){
			printf("     (%c)     ----------%d---------->    (%c)     \n", Ag[i]->origen->info,Ag[i]->info,Ag[i]->destino->info);
		}
		printf("\n");
	}
}
	
void MatrizAdy(NodoG* G, AristaG* Ag){
	int i;
	int j;
	int **MatrizAdyacente;
	MatrizAdyacente=(int **)malloc(NumVertices*sizeof(int));
	for(i=0;i<=NumVertices;i++){
		MatrizAdyacente[i]=(int *)malloc(NumVertices*sizeof(int));
	}
	for(i=0;i<=NumVertices;i++){
		for(j=0;j<=NumVertices;j++){
			MatrizAdyacente[i][j]=0;
		}
	}
	for(i=0; i<NumVertices;i++){
		MatrizAdyacente[Ag[i]->origen->pos][Ag[i]->destino->pos]=1;
	}
	for(i=0; i<NumVertices;i++){
		printf("  %d",i+1);
	}
	
	for(i=0; i<NumVertices;i++){
		printf("\n%d ",i+1);
		for(j=0; j<NumVertices;j++){
			printf("[%d] ",MatrizAdyacente[i][j]);
		}
	}
}
	
void ListaAdyacente(NodoG* G,AristaG* Ag){
	nodo *ListAdy;
	int i;
	ListAdy=(nodo **)malloc((NumVertices)*sizeof(nodo));
	for(i=0; i<NumVertices;i++){
		ListAdy[i]=nuevoNodoL(-1,NULL);
	}
	for(i=0; i<NumAristas;i++){
		if(ListAdy[Ag[i]->origen->pos]->info==-1){
			ListAdy[Ag[i]->origen->pos]->info=Ag[i]->origen->info;
		}
		Lista=ListAdy[Ag[i]->origen->pos];
		p=Lista;
		t=RecorrerUltimo(Lista);
		CrearFinal(Ag[i]->destino->info);
	}
	printf("\n\n");
	for(i=0; i<NumVertices; i++){
		printf("ListAdy [%c]->",ListAdy[i]->info);
		Recorrer(ListAdy[i]->liga);
		printf("\n");
	}
}
	
void MatrizDistanciaF(NodoG* G,AristaG* Ag){
	int i;
	int j;
	MatrizDistancia=(int **)malloc(NumVertices*sizeof(int));
	for(i=0;i<NumVertices;i++){
		MatrizDistancia[i]=(int *)malloc(NumVertices*sizeof(int));
	}
	for(i=0;i<NumVertices;i++){
		for(j=0;j<NumVertices;j++){
			if(i==j){
				MatrizDistancia[i][j]=0;
			}else{
				MatrizDistancia[i][j]=-1;
			}
		}
	}
	for(i=0; i<NumAristas;i++){
		MatrizDistancia[Ag[i]->origen->pos][Ag[i]->destino->pos]=Ag[i]->info;
	}
	printf("\n");
	for(i=0; i<NumVertices;i++){
		printf("  %c",G[i]->info);
	}
	
	for(i=0; i<NumVertices;i++){
		printf("\n%c ",G[i]->info);
		for(j=0; j<NumVertices;j++){
			printf("[%d]   ",MatrizDistancia[i][j]);
		}
	}
	printf("\n");
}
#endif