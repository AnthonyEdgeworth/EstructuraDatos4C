#include "arbolBal.h"

void inicializarGlobales(void){
	nodo1=NULL;
	nodo2=NULL;
	aux=NULL;
	aux1=NULL;
	otro=NULL;
}

NodoA nuevoNodo(NodoA izq,int inf,int FE,NodoA der){
	NodoA q;
	q=(NodoA)malloc(sizeof(tiponodo));
	if (!q){
		puts("Error al crear el nuevo nodo");
		exit(0);
	}
	
	q->info=inf;
	q->izq=izq;
	q->der=der;
	q->FE=FE;
	return q;
}

NodoA Inserta_Balanceado(NodoA nodo,bool balance, int info){ //al iniciar es falso
	if (nodo!=NULL){
		if(info<nodo->info){
			nodo->izq=Inserta_Balanceado(nodo->izq,balance,info);
			if(balance==true){
				if(nodo->FE==1){
					nodo->FE=0;
					balance=false;
				} else if(nodo->FE==0)
					nodo->FE=-1;
				else if(nodo->FE==-1){
					nodo1=nodo->izq;
					if(nodo1->FE<=0) {
						nodo->izq=nodo1->der;
						nodo1->der=nodo;
						nodo->FE=0;
						nodo=nodo1;
					} else {
						nodo2=nodo1->der;
						nodo->izq=nodo2->der;
						nodo2->der=nodo;
						nodo1->der=nodo2->izq;
						nodo2->izq=nodo1;
						
						if (nodo2->FE=-1)
							nodo->FE=1;
						else
							nodo->FE=0;
							
						if (nodo2->FE==1)
							nodo1->FE=-1;
						else
							nodo1->FE=0;
						nodo=nodo2;
					}
					nodo->FE=0;
					balance=false;
				}
			} else
			return nodo;
		} else if(info>nodo->info) {
			nodo->der=Inserta_Balanceado(nodo->der,balance, info);
			if(balance==true){
				if (nodo->FE==-1){
					nodo->FE=0;
					balance=false;
				} else if(nodo->FE==0)
					nodo->FE=1;
				else if(nodo->FE==1){
					nodo1=nodo->der;

					if(nodo1->FE>=0){
						nodo->der=nodo1->izq;
						nodo1->izq=nodo;
						nodo->FE=0;
						nodo=nodo1;
					} else {
						nodo2=nodo1->izq;
						nodo->der=nodo2->izq;
						nodo2->izq=nodo;
						nodo1->izq=nodo2->der;
						nodo2->der=nodo1;
						if(nodo2->FE==1)
							nodo->FE=-1;
						else
							nodo->FE=0;

						if(nodo2->FE=-1)
							nodo1->FE=1;
						else
							nodo1->FE=0;
						nodo=nodo2;
					}
					nodo->FE=0;
					balance=false;
				}
			} else
				return nodo;
		} else {
			puts("El dato ya existe");
			return nodo;
		}
	} else {
		balance=true;
		nodo=nuevoNodo(NULL,info,0,NULL);
		return nodo;
	}
}

void Restructura_Izq(NodoA nodo, bool balance){
	if (balance==true){
		if(nodo->FE==-1)
			nodo->FE=0;
		else if(nodo->FE==0){
			nodo->FE=1;
			balance=false;
		} else if(nodo->FE==1){
			nodo1=nodo->der;
			if(nodo1->FE>=0){
				nodo->der=nodo1->izq;
				nodo1->izq=nodo;
				if(nodo1->FE==0){
					nodo->FE=1;
					nodo1->FE=-1;
					balance=false;
				} else if(nodo1->FE==1){
					nodo->FE=0;
					nodo1->FE=0;
				}
				nodo=nodo1;
			} else {
				nodo2=nodo1->izq;
				nodo->der=nodo2->izq;
				nodo2->izq=nodo;
				nodo1->izq=nodo2->der;
				nodo2->der=nodo1;
				if (nodo2->FE==1)
					nodo->FE=-1;
				else
					nodo->FE=0;
					
				if(nodo2->FE=-1)
					nodo1->FE=1;
				else
					nodo1->FE=0;
				nodo=nodo2;
				nodo2->FE=0;
			}
		}
	}
}


void Restructura_Der(NodoA nodo, bool balance){
	if(balance==true){
		if(nodo->FE==1)
			nodo->FE=0;
		else if(nodo->FE==0){
			nodo->FE=-1;
			balance=false;
		} else if(nodo->FE==-1){
			nodo1=nodo->izq;
			if(nodo1->FE<=0){
				nodo->izq=nodo1->der;
				nodo1->der=nodo;
				if (nodo1->FE==0){
					nodo->FE=-1;
					nodo1->FE=1;
					balance=false;
				} else if(nodo1->FE=-1){
					nodo->FE=0;
					nodo1->FE=0;
				}
				nodo=nodo1;
			} else {
				nodo2=nodo1->der;
				nodo->izq=nodo2->der;
				nodo2->der=nodo;
				nodo1->der=nodo2->izq;
				nodo2->izq=nodo1;
				if(nodo2->FE==-1)
					nodo->FE=1;
				else
					nodo->FE=0;

				if(nodo2->FE==1)
					nodo1->FE=-1;
				else
					nodo1->FE=0;
				nodo=nodo2;
				nodo2->FE=0;
			}
		}
	}
}

NodoA Elimina_Balanceado(NodoA nodo,bool balance, int info){
	if(nodo!=NULL){
		if(info<nodo->info){
			nodo->izq=Elimina_Balanceado(nodo->izq,balance,info);
			Restructura_Izq(nodo,balance);
		} else if(info>nodo->info){
			nodo->der=Elimina_Balanceado(nodo->der,balance,info);
			Restructura_Der(nodo,balance);
		} else {
			otro=nodo;
			balance=true;
			if(otro->der==NULL)
				nodo=otro->izq;
			else {
				if(otro->izq==NULL)
					nodo=otro->der;
				else {
					aux=nodo->izq;
					balance=false;
					while(aux->der!=NULL){
						aux1=aux;
						aux=aux->der;
						balance=true;
					}
					nodo->info=aux->info;
					otro=aux;
					if(balance==true)
						aux1->der=aux->izq;
					else
						nodo->izq=aux->izq;
					Restructura_Der(nodo->izq,balance);
				}
			}
			free(otro);
		}
	} else
		puts("Arbol vacio");
	return nodo;
}

void inorden(NodoA raiz){
	if (raiz!=NULL){
		inorden(raiz->izq);
		printf("%d ",raiz->info);
		inorden(raiz->der);
	}
}

void postorden(NodoA raiz){
	if (raiz!=NULL){
		postorden(raiz->izq);
		postorden(raiz->der);
		printf("%d ", raiz->info);
	}
}

void preorden(NodoA raiz){
	if(raiz!=NULL){
		printf("%d ", raiz->info);
		preorden(raiz->izq);
		preorden(raiz->der);
	}
}