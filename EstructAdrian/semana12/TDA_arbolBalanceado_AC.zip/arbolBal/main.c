#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include "arbolBal.h"

void crear(void);
void imprimir(void);
void eliminar(void);

int main(int argc, char *argv[]){

	crear();
	imprimir();
	eliminar();
}

void crear(void){
	inicializarGlobales();
	
	int elem;
	int continuar;
	int NO = 2;
	
	do{
		puts("Ingrese un elemento a insertar");
		scanf("%d", &elem);
		getchar();
		
		arbol = Inserta_Balanceado(arbol, false, elem);
		
		puts("Desea ingresar un nuevo elemento?");
		puts("1) Si");
		puts("2) No");
		scanf("%d", &continuar);
		getchar();
	} while(continuar != NO);
}

void imprimir(void){
	puts("Estado actual del arbol:");
	
	puts("En inorden");
	inorden(arbol);
	puts("");
	
	puts("En preorden");
	preorden(arbol);
	puts("");
	
	puts("En postorden");
	postorden(arbol);
	puts("");
}

void eliminar(void){
	int elem;
	int continuar;
	int NO = 2;
	
	do{
		puts("Dame el elemento a eliminar");
		scanf("%d",&elem);
		getchar();
		arbol= Elimina_Balanceado(arbol,false,elem );
		
		imprimir();
		
		puts("Que desea hacer a continuacion?");
		puts("1) Eliminar otro elemento");
		puts("2) Salir");
		scanf("%d",&continuar);
		getchar();
	}while(continuar != NO);
}