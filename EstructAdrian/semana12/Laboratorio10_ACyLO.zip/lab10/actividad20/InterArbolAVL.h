//interface para decribri las operaciones de un �rbol binario
//utilizando la memoria din�mica mediante�punteros.
//InterTreeBusqueda.h
#include <stdbool.h>
typedef struct nodoA{
  int info;
	int  FE;
    struct nodoA *izq;
    struct nodoA *der;
}tiponodo;
typedef tiponodo *NodoA;
NodoA arbol;
//bool balance=false;
NodoA nodo1=NULL;
NodoA nodo2=NULL;
NodoA aux=NULL;
NodoA aux1=NULL;
NodoA otro=NULL;

NodoA nuevoNodo(NodoA,int,int,NodoA );
NodoA Inserta_Balanceado(NodoA,bool, int);
void Restructura_Izq(NodoA, bool);
void Restructura_Der(NodoA, bool );
NodoA Elimina_Balanceado(NodoA,bool,int );
//RECORRIDOS DE LOS ARBOLES
void inorden(NodoA );
void preorden (NodoA );
void postorden(NodoA );
int compara(int,int);
void InsertarDato(int);
NodoA elimina(NodoA,int);

void BFS(int);
int graph[10][10], visited[10],total;
