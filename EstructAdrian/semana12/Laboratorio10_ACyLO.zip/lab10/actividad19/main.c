#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include "arbolBal.h"

void crear(int tamano);
void iniciar(void);
void imprimir(void);

int* ordenarAsendente(int* arreglo, int tamano);
int* eliminaRaiz(int* arreglo, int medio, int tamano);

int main(int argc, char *argv[]){

	iniciar();
	imprimir();
}

void iniciar(void){
	inicializarGlobales();
	
	int tamano;
	puts("Ingrese el tamano del arreglo");
	scanf("%d", &tamano);
	getchar();
	
	crear(tamano);	
}

void crear(int tamano){
	int arreglo[tamano];
	
	for(int i = 0; i < tamano; i++){
		printf("Ingrese el elemento %d del arreglo: ", i + 1);
		scanf("%d", &arreglo[i]);
		getchar();
	}
	
	//Paso 1
	//obtener medio del arreglo
	int temp;
		//acomodar en orden asencendente
	for (int i = 0; i < tamano; i++) {
    	for (int l = 0; l < tamano - 1; l++) {
      		if (arreglo[l] > arreglo[l + 1]) {
				temp = arreglo[l];
				arreglo[l] = arreglo[l + 1];
				arreglo[l + 1] = temp;
      		}
    	}
  	}
	//convertirlo en raiz
	int medio = (tamano - 1) / 2;
	arbol = Inserta_Balanceado(arbol, false, arreglo[medio]);
		//eliminar raiz del arreglo
	while(medio < tamano - 1){
		arreglo[medio] = arreglo[medio + 1];
		medio++;
	}
	
	arreglo[tamano - 1] = 0;
	tamano--;
	//2- Ingresar el resto de elementos a partir de la media
	for(int l = 0; l < tamano; l++){
		arbol = Inserta_Balanceado(arbol, false, arreglo[l]);
	}
}

int* ordenarAsendente(int* arreglo, int tamano){
	int temp;
	
	for (int i = 0; i < tamano; i++) {
    	for (int l = 0; l < tamano - 1; l++) {
      		if (arreglo[l] > arreglo[l + 1]) {
				temp = arreglo[l];
				arreglo[l] = arreglo[l + 1];
				arreglo[l + 1] = temp;
      		}
    	}
  	}
  	
  	return arreglo;
}

int* eliminaRaiz(int* arreglo, int medio, int tamano){
	while(medio < tamano - 1){
		arreglo[medio] = arreglo[medio + 1];
		medio++;
	}
	
	arreglo[tamano - 1] = 0;
	
	return arreglo;
}

void imprimir(void){
	puts("Arbol:");
	
	puts("En inorden");
	inorden(arbol);
	puts("");
	
	puts("En preorden");
	preorden(arbol);
	puts("");
	
	puts("En postorden");
	postorden(arbol);
	puts("");
}