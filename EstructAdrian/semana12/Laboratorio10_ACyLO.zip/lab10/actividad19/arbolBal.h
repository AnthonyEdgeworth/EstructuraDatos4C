#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>

typedef struct nodoA{
    int info;
	int  FE;
    struct nodoA *izq;
    struct nodoA *der;
}tiponodo;

typedef tiponodo *NodoA;

NodoA arbol;
NodoA nodo1;
NodoA nodo2;
NodoA aux;
NodoA aux1;
NodoA otro;

void inicializarGlobales(void);//funcion extra agregada para funcionar con .c y .h relacionados
NodoA nuevoNodo(NodoA, int, int, NodoA );
NodoA Inserta_Balanceado(NodoA, bool, int);
void Restructura_Izq(NodoA, bool);
void Restructura_Der(NodoA, bool );
void inorden(NodoA);
void preorden (NodoA);
void postorden(NodoA);
int compara(int, int);