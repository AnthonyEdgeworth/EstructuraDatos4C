//Describe las operaciones que puede realizar
//TDA GRAFOS
//Representaci�n en memoria de un v�rtice de una grafo
//agregar nodo de lista sencilla
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
typedef struct Nodos{
	char info;
	struct Nodos *liga;
}tiponodols;
typedef struct nodoG{
   char info;
   int numAristasInc;
   int numAristaEntra;
   int numAristaSal;
   int pos;
}tiponodo;
typedef struct arista{
   int info;
   bool dirigida;
   struct nodoG *origen;
   struct nodoG *destino;
   int pos;
}tipoArista;
typedef tiponodo *NodoG;
typedef tipoArista *AristaG;
typedef tiponodols *nodo;
nodo p,q,t=NULL;
nodo Lista;
void CrearFinal(int Elem);
//conjuntos de v�rtices
NodoG *Grafos; //utilizaci�n de un arreglo (din�mico)
//conjunto de aristas
AristaG *Aristas;
int NumVertices;
int NumAristas;
//operaciones crear grafo en memoria
NodoG NuevoNodoG(char,int,int,int,int);
NodoG* CargarGrafo(); //retorna el conjunto de v�rtices (arreglo)
void MuestraConjuntoVertice(NodoG*);
void MuestraGrafo(NodoG*);
//operaciones aristas
AristaG NuevaArista(int,NodoG,NodoG,bool,int );
AristaG* CrearAristas();
NodoG aVertice(char,NodoG *);
void MuestraConjuntoAristas(AristaG*);
void MatrizAdy(NodoG*,AristaG*);//genera y muestra
void ListaAdyacente(NodoG*,AristaG*);
void MatrizDistanciaF(NodoG* G,AristaG* Ag);

//operaciones de lista enlazada para crear la ListaAdyacente
nodo nuevoNodoL(char inf,nodo liga){
	nodo q;
	q=(nodo)malloc(sizeof(tiponodols));
	if (!q){
		printf("\n Error al crear el nuevo nodo");
		exit(0);
	}
	q->info=inf;
	q->liga=liga;

	return q;
}
void CrearFinal(int Elem){
	nodo n;
	if (p==NULL) //ES el primer nodo
	{
		p=nuevoNodoL(Elem,NULL);
		t=p;
	}
	else{ //nodos subsecuentes
		n=nuevoNodoL(Elem,NULL);
		t->liga=n;
		t=n;
	}
}
nodo RecorrerUltimo(nodo lista){
	t=lista;
	while (lista!=NULL){
		t=lista;
		lista=lista->liga;
	}
	return t;
}

void Recorrer(nodo Lista){
	while (Lista!=NULL){
		printf("%c -> ",Lista->info);
		Lista=Lista->liga;
	}
}
