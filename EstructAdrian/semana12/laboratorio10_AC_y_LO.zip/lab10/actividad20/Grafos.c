#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<ctype.h>
#include"InterGrafos.h"



void FloydAlgorithm();
bool es_Infinito(int, int, int);

//variables Globales
//arreglos
NodoG *ArrayGrafos;
AristaG *ArrayAristas;
//matriz dinamica
int **MatrizDistancia;
int main(int argc, char *argv[]) {
	ArrayGrafos=CargarGrafo();
	printf("\nConjunto de vertices del grafo \n");
	MuestraConjuntoVertice(ArrayGrafos);
	ArrayAristas=CrearAristas();
	printf("\nConjunto de aristas del grafo \n");
	MuestraConjuntoAristas(ArrayAristas);
	MatrizAdy(ArrayGrafos,ArrayAristas);
	ListaAdyacente(ArrayGrafos,ArrayAristas);
	printf("\nMatriz de distancia \n");
	MatrizDistanciaF(ArrayGrafos,ArrayAristas);
	FloydAlgorithm();

	getch();
	return 0;
}

//cuerpo de funciones
NodoG NuevoNodoG(char dato, int Ninc, int Nentra, int Nsal, int p){
	NodoG n;
	n=(NodoG)malloc(sizeof (tiponodo));
	if(!n){
		printf("\nError al crear vertice \n");
		exit(0);
	}
	n->info=dato;
	n->numAristasInc=Ninc;
	n->numAristaEntra=Nentra;
	n->numAristaSal=Nsal;
	n->pos=p;
	return n;
}
NodoG* CargarGrafo(){
	char dato;
	int nInc=0, nEntra=0, nSal=0;
	NodoG * Grafos;
	printf("\nCuantos vertices tiene el grafo? ");
	scanf("%d",&NumVertices);
	fflush(stdin);
	//Reserva la memoria para el arreglo dinamico
	Grafos=(NodoG *)malloc (NumVertices *sizeof(tiponodo));
	for(int i=0; i<NumVertices;i++){
		fflush(stdin);
		printf("\nDame la informacion del vertice %d\n",i);
		scanf("%c",&dato);
		fflush(stdin);
		printf("Dame el num de las aristas incidentes del vertice %d\n",i);
		scanf("%d",&nInc);
		printf("Dame el num aristas entrantes del vertice %d\n",i);
		scanf("%d",&nEntra);
		printf("Dame el num aristas salientes del vertice %d\n",i);
		scanf("%d",&nSal);
		Grafos[i]=NuevoNodoG(dato, nInc, nEntra, nSal, i);
	}
	getch();
	return Grafos;
}
void MuestraConjuntoVertice(NodoG* Vg){
	for(int i=0;i<NumVertices;i++){
		printf("   Vertice = [%c] \n",Vg[i]->info);
	}
}

AristaG NuevaArista(int dato, NodoG Origen, NodoG Destino, bool dirigida, int p){
	AristaG a;
	a=(AristaG)malloc(sizeof (tipoArista));//posisionas
	if(!a){
		printf("\nError no se pudo crear la arista \n");
		return NULL;
	}// a en pocicion -> 
	a->info=dato;
	a->origen=Origen;
	a->destino=Destino;
	a->dirigida=dirigida;
	a->pos=p;
	return a;
}
AristaG* CrearAristas(){
	int dato;
	char o,d;
	bool dir;
	char opc;
	NodoG ori,dest;
	
	printf("\n�Cuantas aristas tiene el grafo? ");
	scanf("%d",&NumAristas);
	fflush(stdin);
	Aristas=(AristaG *)malloc(NumAristas * sizeof(tipoArista));//pociciona 
	for(int i=0; i<NumAristas; i++){
		fflush(stdin);
		printf("Dame el nombre o  peso de la arista (inserta 0 si no tiene) ");
		scanf("%d",&dato);
		fflush(stdin);
		printf("Dame el nodo origen ");
		scanf("%c",&o);//o de origen jaja
		fflush(stdin);
		printf("Dame el nodo destino ");
		scanf("%c",&d);
		fflush(stdin);
		ori=aVertice(o,ArrayGrafos);
		if(ori==NULL){
			printf("\n No existe el vertice origen\n");
			exit(0);
		}
		dest=aVertice(d,ArrayGrafos);
		if(dest==NULL){
			printf("\n No existe el vertice destino \n");
			exit(0);
		}
		printf("\n �La arista es dirgida? S/N: ");
		scanf("%c",&opc);
		if(toupper(opc)=='S'){
			dir=true;
		}
		else if(toupper(opc)=='N'){
			dir=false;
		}
		Aristas[i]=NuevaArista(dato,ori,dest,dir,i);
	}
	printf("\n");
	return Aristas;
}

NodoG aVertice(char v, NodoG *grafo){
	if(grafo!=NULL){
		for(int i=0; i<NumVertices;i++){
			if(v==grafo[i]->info)
				return grafo[i];
		}
	}
	return NULL;
}
void MuestraConjuntoAristas(AristaG *Ag){
	printf("\nNodo Origen -------- Arista -------- Nodo Destino\n");
	for(int i=0; i<NumAristas; i++){
		if(Ag[i]->dirigida==false)
		   printf("   (%c) ------------- %d ------------- (%c)   \n",
				Ag[i]->origen->info, Ag[i]->info, Ag[i]->destino->info);
		else if(Ag[i]->dirigida==true)
			printf("   (%c) ------------- %d -----------> (%c)   \n",
				   Ag[i]->origen->info, Ag[i]->info, Ag[i]->destino->info);
		printf("\n");
	}
}
void MatrizAdy(NodoG* G, AristaG* Ag){
	//matriz dinamica
	int **MatrizAdyacente;
	MatrizAdyacente=(int **) malloc(NumVertices * sizeof(int **));
	for (int i=0;i<=NumVertices; i++){
		MatrizAdyacente[i]=(int *) malloc(NumVertices*sizeof(int));
	}
	for(int i=0; i<NumVertices;i++){
		for(int j=0;j<NumVertices;j++){
			MatrizAdyacente[i][j]=0;
		}
	}
	for(int i=0;i<NumAristas;i++){
		MatrizAdyacente[Ag[i]->origen->pos][Ag[i]->destino->pos]=1;
	}
	for(int i=0;i<NumVertices;i++){//encabezado
		printf("    %d    ",i+1);
	}

	for(int i=0;i<NumVertices;i++){
		printf("\n %d   ",i+1);
		for(int j=0; j<NumVertices; j++){
			printf(" [%d]   ",MatrizAdyacente[i][j]);
		}
	}
}

void ListaAdyacente(NodoG* G, AristaG* Ag){
	//arreglo dinamico de nodo de lista enlazada sencilla
	nodo *ListAdy;
	ListAdy=(nodo *)malloc((NumVertices)*sizeof(nodo*));
	for(int i=0;i<NumVertices;i++){
		ListAdy[i]=nuevoNodoL(-1,NULL);
	}
	for(int i=0;i<NumAristas;i++){
		if(ListAdy[Ag[i]->origen->pos]->info==-1){
			ListAdy[Ag[i]->origen->pos]->info=Ag[i]->origen->info;
		}
		Lista=ListAdy[Ag[i]->origen->pos];
		p=Lista;
		t=RecorrerUltimo(Lista);
		CrearFinal(Ag[i]->destino->info);
	}
	printf("\n");
	for(int i=0;i<NumVertices;i++){
		printf(" ListaAdy [%c]-> ",ListAdy[i]->info);
		Recorrer(ListAdy[i]->liga);
		printf("\n");
	}
}

void MatrizDistanciaF(NodoG* G, AristaG* Ag){
	MatrizDistancia=(int **)malloc(NumVertices*sizeof(int*));
	for(int i=0;i<=NumVertices;i++){
		MatrizDistancia[i]=(int *)malloc(NumVertices*sizeof(int));
	}
	for(int i=0;i<NumVertices; i++){
		for(int j=0;j<NumVertices;j++){
			if(i==j)
				MatrizDistancia[i][j]=0;
			else
				MatrizDistancia[i][j]=-1;//-1 representa infinito
		}
	}
	for(int i=0;i<NumAristas;i++){
		MatrizDistancia[Ag[i]->origen->pos][Ag[i]->destino->pos]=Ag[i]->info;
	}
	for(int i=0;i<NumVertices;i++){//encabezado
		printf("    %c   ",G[i]->info);
	}
	for(int i=0;i<NumVertices;i++){
		printf("\n %c   ",G[i]->info);
		for(int j=0;j<NumVertices;j++){
			printf(" [%d]   ",MatrizDistancia[i][j]);
		}
	}
}

void FloydAlgorithm(){
  for(int k = 0; k < NumVertices; k++){
    for(int i = 0; i < NumVertices; i++){
      for(int j = 0; j < NumVertices; j++){
/*Si los valores no son infinitos, proceden a hacer la segunda condicional*/
          if(es_Infinito(MatrizDistancia[i][k], MatrizDistancia[k][j], MatrizDistancia[i][j] )==false){
	          if((MatrizDistancia[i][k]+MatrizDistancia[k][j])<MatrizDistancia[i][j]){
	              MatrizDistancia[i][j] = MatrizDistancia[i][k] + MatrizDistancia[k][j];
	          }
          }
      }
    }
  }

	printf("\nAlgoritmo de Floyd\n");
	for (int i = 0; i < NumVertices; i++){
    printf("\n%c  ", ArrayGrafos[i]->info);
    for(int j = 0; j < NumVertices; j++){
      printf("[%d]  ", MatrizDistancia[i][j]);
    }
  }

}

bool es_Infinito(int numero1, int numero2, int numero3){
  if(numero1==-1 || numero2==-1 || numero3==-1)
    return  true;
  else
    return false;
}
