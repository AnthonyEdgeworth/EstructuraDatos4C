#include  <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdbool.h>
typedef struct nodoA{
	int info;
	int  FE;
	struct nodoA *izq;
	struct nodoA *der;
}tiponodo;
typedef tiponodo *NodoA;
NodoA arbol;
//bool balance=false;
NodoA nodo1=NULL;
NodoA nodo2=NULL;
NodoA aux=NULL;
NodoA aux1=NULL;
NodoA otro=NULL;

NodoA nuevoNodo(NodoA,int,int,NodoA );
NodoA Inserta_Balanceado(NodoA,bool, int);
void Restructura_Izq(NodoA, bool);
void Restructura_Der(NodoA, bool );
NodoA Elimina_Balanceado(NodoA,bool,int );
//RECORRIDOS DE LOS ARBOLES
void inorden(NodoA );
void preorden (NodoA );
void postorden(NodoA );
int compara(int,int);
void InsertarDato(int);
NodoA elimina(NodoA,int);

void BFS(int);
int graph[10][10], visited[10],total;


int main(int argc, char **argv){
	int elemento, elementoElimina;
	do{
		printf("\nDame el elemento >> presiona 0 para terminar \n");
		scanf("%d",&elemento);
		if(elemento!=0)
			arbol=Inserta_Balanceado(arbol,false,elemento);
	}while(elemento!=0);
	printf("\narbol en indorden\n");
	inorden(arbol);
	printf("\narbol en pos orden\n");
	postorden(arbol);	
	printf("\narbol en preorden\n");
	preorden(arbol);
	//------bfs--------
	int i,j;
	printf("\nEnter el total de numero de vertices en el grafo\n");
	scanf("%d",&total);
	/*Adjacency matrix input*/
	printf("\nEnter the cuadro matrix  \n");
	for(i=0;i<total;i++)
	{
		for(j=0;j<total;j++)
		{
			scanf("%d",&graph[i][j]);
		}
	}
	for(i=0;i<total;i++)
	{
		visited[i] = 0;
	}
	printf("\nBFS traversal is \n");
	BFS(0);
	//----------------------
	
	do{
		printf("\nDame el elementoa eliminar >> presiona 0 para terminar\n");
		scanf("%d",&elementoElimina);
		arbol=Elimina_Balanceado(arbol,false,elementoElimina);
		printf("\narbol en indorden\n");
		inorden(arbol);
	}while(elementoElimina!=0);

  return 0;
}

NodoA nuevoNodo(NodoA izq, int inf, int FE, NodoA der){
  NodoA q;

  q = (NodoA)malloc(sizeof(tiponodo));

  if(!q){
    printf("\n Error al crear el nuevo Nodo");
    exit(0);
  }

  q->info = inf;
  q->izq = izq;
  q->der = der;
  q->FE = FE;

  return q;
}

NodoA Inserta_Balanceado(NodoA nodo, bool balance, int info){
  
	if(nodo!=NULL){
		/*balance = false*/
		if(info<nodo->info){
			nodo->izq=Inserta_Balanceado(nodo->izq, balance,info);
			if(balance==true){
				if(nodo->FE==1){
					nodo->FE=0;
					balance = false;
				}
				else if(nodo->FE==0)
				   nodo->FE=-1;
				else if(nodo->FE==-1){
					nodo1=nodo->izq;
					if(nodo1->FE<=0){/*rotacion II*/
						nodo->izq=nodo1->der;
						nodo1->der=nodo;
						nodo->FE=0;
						nodo=nodo1;
					}/*fin rotacion II*/
					else{/*rotacion ID*/
						nodo2=nodo1->der;
						nodo->izq=nodo2->der;
						nodo2->der=nodo;
						nodo1->der=nodo2->izq;
						nodo2->izq=nodo1;
						if(nodo2->FE==-1)
							nodo->FE=1;
						else
							nodo->FE=0;
						if(nodo2->FE==1)
							nodo1->FE=-1;
						else
							nodo1->FE=0;
						nodo=nodo2;
					}/*fin rotacion ID*/
					nodo->FE=0;
					balance=false;
				}
			}
			else
			   return nodo;
		}/*fin DEL es menor*/
		else if(info>nodo->info){
			nodo->der=Inserta_Balanceado(nodo->der, balance, info);
			if(balance==true){
				if(nodo->FE==-1){
					nodo->FE=0;
					balance=false;
				}
				else if(nodo->FE==0)
				   nodo->FE=1;
				else if(nodo->FE==1){
					nodo1=nodo->der;
					
					if(nodo1->FE>=0){/*rotacion DD*/
						nodo->der=nodo1->izq;
						nodo1->izq=nodo;
						nodo->FE=0;
						nodo=nodo1;
					}/*ternina rotacion DD*/
					else{/*rotacion DI*/
						nodo2=nodo1->izq;
						nodo->der=nodo2->izq;
						nodo2->izq=nodo;
						nodo1->izq=nodo2->der;
						nodo2->der=nodo1;
						if(nodo2->FE==1)
							nodo->FE=-1;
						else
							nodo->FE=0;
						
						if(nodo2->FE=-1)
							nodo1->FE=1;
						else
							nodo1->FE=0;
						
						nodo=nodo2;
					}/*fin rotacion DI*/
					nodo->FE=0;
					balance=false;
				}
			}
			else 
			   return nodo;
		}/*fin es mayor*/
		else{
			printf("\n La informacion ya se encuentra en el arbol\n");
			return nodo;
		}
	}/*fin del if is null*/
	else{
		balance = true;
		nodo=nuevoNodo(NULL,info, 0, NULL);
		return nodo;
	}
}	
	/*eliminacion*/
	
void Restructura_Izq(NodoA nodo, bool balance){
	if(balance==true){
		if(nodo->FE==-1)
			nodo->FE=0;
		else if(nodo->FE==0){
			nodo->FE=1;
			balance=false;
		}
		else if(nodo->FE==1){/*reestructuracion del arbol*/
			nodo1=nodo->der;
			if(nodo1->FE>=0){/*rotacion DD*/
				nodo->FE=1;
				nodo1->FE=-1;
				balance=false;
			}else if(nodo1->FE==1){
				nodo->FE=0;
				nodo1->FE=0;
			}
			nodo=nodo1;
		}/*termina rotacion DD*/
	}else{/*rotacion DI*/
		nodo2=nodo1->izq;
		nodo->der=nodo2->izq;
		nodo2->izq = nodo;
		nodo1->izq=nodo2->der;
		nodo2->der=nodo1;

		if(nodo2->FE==1)
			nodo->FE=-1;
		else
			nodo->FE=0;
		if(nodo2->FE==-1)
			nodo1->FE=1;
		else
			nodo1->FE=0;

			nodo=nodo2;
			nodo2->FE=0;

		/*termina rotacion DI*/									
	}
}

void Restructura_Der(NodoA nodo, bool balance){
	if(balance==true){
		if(nodo->FE==1)
			nodo->FE=0;
		else if(nodo->FE==0){
			nodo->FE=-1;
			balance=false;
		}
		else if(nodo->FE==-1){/*restructuracion del arbol*/
				nodo1=nodo->izq;
				if(nodo1->FE<=0){/*rotacion II*/
					nodo->izq=nodo1->der;
					nodo1->der=nodo1->izq;
					if(nodo1->FE==0){
						nodo->FE=-1;
						nodo1->FE=1;
						balance=false;
					}else if(nodo1->FE==-1){
						nodo->FE=0;
						nodo1->FE=0;
					}
					nodo=nodo1;
				}/*fin rotacion II*/
		}
		else{/*rotacion ID*/
			nodo2=nodo1->der;
			nodo->izq=nodo2->der;
			nodo2->der=nodo;
			nodo1->der=nodo2->izq;
			nodo2->izq=nodo1;
			if(nodo2->FE==-1)
				nodo->FE=1;
			else
				nodo->FE=0;
			if(nodo2->FE==1)
				nodo1->FE=-1;
			else
				nodo1->FE=0;
			nodo=nodo2;
			nodo2->FE=0;
		}/*fin rotacion ID*/
	}/*fin balance*/
}

NodoA Elimina_Balanceado(NodoA nodo, bool balance, int info){
	if(nodo!=NULL){
		if(info<nodo->info){
			nodo->izq=Elimina_Balanceado(nodo->izq,balance,info);
			Restructura_Izq(nodo,balance);
		}/*es menor*/
		else if(info>nodo->info){
			nodo->der=Elimina_Balanceado(nodo->der, balance,info);
			Restructura_Der(nodo,balance);
		}/*fin es mayor*/
		else{
			otro=nodo;
			balance=true;
			if(otro->der==NULL){
				nodo=otro->izq;
			}/*fin si otros es NULL*/
			else{
				if(otro->izq==NULL)
					nodo=otro->der;
				else{
					aux=nodo->izq;
					balance=false;
					while(aux->der!=NULL){
						aux1=aux->der;
						aux=aux->der;
						balance=true;
					}
					nodo->info=aux->info;
					otro=aux;
					if(balance==true)
						aux1->der=aux->izq;
					else
						nodo->izq=aux->izq;
						Restructura_Der(nodo->izq,balance);
				}/*fin del else otro->izq==NULL*/
			}
		}
		free(otro);
	}/*fin del NULL*/	
	else
		printf("arbol vacio");
	return nodo;
}

void inorden(NodoA raiz){
	if(raiz != NULL){
		inorden(raiz->izq);
		printf(" %d", raiz->info);
		inorden(raiz->der);
	}
}

void preorden(NodoA raiz){
  if(raiz != NULL){
    printf(" %d", raiz->info);
    preorden(raiz->izq);
    preorden(raiz->der);
  }
}

void postorden(NodoA raiz){
  if(raiz != NULL){
    postorden(raiz->izq);
    postorden(raiz->der);
    printf(" %d", raiz->info);
  }
}

 // void insertar(NodoA t, int x){
/*
	  int v = x->raiz->t;
	  if(v!=t){v =NULL;}
	  while((v !=NULL)&&(*v!=x)){
		  if(x<*v){
			if()
		  }
	  }
  } 
*/

  void BFS(int vertex)
  {
	  int j;
	  printf("%d\t",vertex);
	  visited[vertex] = 1;
	  for(j=0;j<total;j++)
	  {
		  if(!visited[j] && graph[vertex][j] == 1 )
		  {
			  BFS(j);
		  }
	  }
  }
