#ifndef _COLA_H
#define _COLA_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void crear(int tamano);
bool desbordamiento(int tamano);
bool subDesbordamiento(void);
void agregar(int n, int tamano);
void eliminar(void);
void mover(void);
void ver(int tamano);
void tamanno(void);

#endif