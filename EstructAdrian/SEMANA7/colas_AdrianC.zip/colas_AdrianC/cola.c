#include "cola.h"

int *cola;
int contador;

void crear(int tamano){
	contador = 0;
	
	cola = (int*)malloc(tamano*sizeof(int));
	for(int i = 0; i < tamano; i++){
		cola[i] = 0;
	}
}

bool desbordamiento(int tamano){
	if(contador>=tamano)
	return  true;
	else
	return false;
}

bool subDesbordamiento(){
	if(contador<0)
	return true;
	else
	return false;
}

void agregar(int n, int tamano){
	if(desbordamiento(tamano)){
		puts("Advertencia: Espacion insuficiente");
		puts("Desbordamiento de pila");
	}
	else{
		cola[contador] = n;
		contador = contador +1;
	}
}

void eliminar(){
	if(subDesbordamiento()){
		puts("Subdesbordamiento de pila");
	}
	else{
		mover();
		cola[contador--] = 0;
	}
}

void mover(){
	for(int i=0; i < contador; i++)
		cola[i] = cola[i+1];
}

void ver(int tamano){
	puts("La cola es:");
	for(int i=0; i < contador; i++)
		printf("%d\n", cola[i]);
}

void tamanno(){
	printf("El espacio total utilizado de la pila es %d\n", contador);
}