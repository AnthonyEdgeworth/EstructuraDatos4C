#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "cola.h"

#define No 5
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void menu(void);
void realizar(int tamano, int tipo);

int main(int argc, char *argv[]) {
	
	int tamano;
	int continuar;
	
	puts("Ingrese el tamanno de la cola");
	scanf("%d", &tamano);
	getchar();
	
	crear(tamano);
	
	do{
		menu();
		scanf("%d", &continuar);
		getchar();
		
		realizar(tamano, continuar);
	}while(continuar != No);
	
	return 0;
}

void menu(){
	puts("Menu de acciones");
	puts("1) Agregar");
	puts("2) Eliminar");
	puts("3) Ver contenido");
	puts("4) Ver tamanno pila actual");
	puts("5) Salir");
}

void realizar(int tamano, int tipo){
	int numero;
				
	switch(tipo){
		case 1:
			puts("Ingrese el numero");
			scanf("%d", &numero);
			getchar();
			agregar(numero, tamano);
			break;
		case 2:
			eliminar();
			break;
		case 3:
			ver(tamano);
			break;
		case 4:
			tamanno();
			break;
		case 5:
			break;
		default:
			puts("Opcion invalida, intente nuevamente");
	}
}
