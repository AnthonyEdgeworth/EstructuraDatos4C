#ifndef _COLASCSR_H 
#define _COLASCSR_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void crear(int tamano);
bool isEmpty(void);
bool isFull(void);
void agregar(void);
void eliminar(void);
void mostrar(void);

#endif