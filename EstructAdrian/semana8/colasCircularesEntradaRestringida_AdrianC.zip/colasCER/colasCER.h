#ifndef _COLASCER_H 
#define _COLASCER_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void crear(int tamano);
bool isEmpty(void);
bool isFull(void);
void agregar(void);
void eliminar(void);
void mostrar(void);

#endif