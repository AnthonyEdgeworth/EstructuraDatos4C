#include "colasC.h"

nuevaI cola[20];
int frente;
int final;
int TamM;

void crear(){
	for(int i = 0; i<20; i++){
		for(int j = 0; j < 20; j++){
			cola[i].propietario[j] = 00;
			cola[i].nombre[j] = 00;
		}

		for(int k = 0; k < 10; k++){
			cola[i].estado[k] = 00;
			cola[i].fecha[k] = 00;
			cola[i].hora[k] = 00;
		}
		
		cola[i].tamano = 0;
	}
	final = 0;
	frente = 0;
	TamM = 20;
}

bool isEmpty(void){
	if(final == frente)
		return true;
	else
	return false;
	if(frente == TamM)
		frente = 0;
}

bool isFull(void){
	if(final - frente == TamM)
		return true;
	else{
		return false;
	}
	if(final == TamM)
		final = 0;
}

void agregar(void){
	if(isFull()){
		puts("ADVERTENCIA: Espacio insuficiente");
		puts("Desbordamiento de cola");
	}
	else{
		puts("Ingrese el nombre del propietario");
		gets(cola[final].propietario);
		puts("Ingrese el nombre del documento");
		gets(cola[final].nombre);
		puts("Ingrese el estado del documento");
		gets(cola[final].estado);
		puts("Ingrese la fecha");
		gets(cola[final].fecha);
		puts("Ingrese la hora");
		gets(cola[final].hora);
		puts("Ingrese el tamanno del documento");
		scanf("%d", &cola[final].tamano);
		getchar();
		
		final++;
	}
}

void eliminar(void){
	if(isEmpty()){
		puts("ADEVERTENCIA: No hay elementos");
		puts("Subdesbordamiento de cola");
	}
	else{
		puts("Espere un momento, el archivo se esta imprimiendo");
		Sleep(cola[frente].tamano * 100);
		for(int j = 0; j < 20; j++){
			cola[frente].propietario[j] = 00;
			cola[frente].nombre[j] = 00;
		}

		for(int k = 0; k < 10; k++){
			cola[frente].estado[k] = 00;
			cola[frente].fecha[k] = 00;
			cola[frente].hora[k] = 00;
		}
		
		cola[frente].tamano = 0;
		
		frente++;
	}
}

void mostrar(void){
	int i = frente;
	puts("Las impresiones restantes son: ");
	
	while(i > final){
		if(i<TamM){
			printf("Propietario: %s\n", cola[i].propietario);
			printf("Nombre del documento: %s\n", cola[i].nombre);
			printf("Estado del documento: %s\n", cola[i].estado);
			printf("Fecha: %s\n", cola[i].fecha);
			printf("Hora: %s\n", cola[i].hora);
			printf("Tamanno del documento: %d Kb\n", cola[i].tamano);
			puts("");
			i++;
		}
		else{
			i = 0;
		}
	}
	while(i < final){
		printf("Propietario: %s\n", cola[i].propietario);
		printf("Nombre del documento: %s\n", cola[i].nombre);
		printf("Estado del documento: %s\n", cola[i].estado);
		printf("Fecha: %s\n", cola[i].fecha);
		printf("Hora: %s\n", cola[i].hora);
		printf("Tamanno del documento: %d Kb\n", cola[i].tamano);
		puts("");
		i++;
	}
}