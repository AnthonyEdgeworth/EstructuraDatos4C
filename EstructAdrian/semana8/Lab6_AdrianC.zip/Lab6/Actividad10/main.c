#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <windows.h>

#include "colasC.h"

void menu(void);
void realizar(int opcion);

int main(int argc, char *argv[]){
	int opcion;
	
	crear();
	do{
		menu();
		scanf("%d", &opcion);
		getchar();
		realizar(opcion);
		puts("");
	}while(opcion != 4);
}

void menu(void){
	puts("Menu de acciones");
	puts("1) Agregar nueva impresion");
	puts("2) Imprimir un archivo");
	puts("3) Mostrar impresiones faltantes");
	puts("4) Salir");
}

void realizar(int opcion){
	switch(opcion){
		case 1:
			agregar();
			break;
		case 2:
			eliminar();
			break;
		case 3:
			mostrar();
			break;
		case 4:
			break;
		default:
			puts("Opcion invalida");
			puts("Intente nuevamente");
	}
}