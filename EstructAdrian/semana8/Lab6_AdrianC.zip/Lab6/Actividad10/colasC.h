#ifndef _COLASC_H 
#define _COLASC_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <windows.h>

typedef struct{
	char propietario[20];
	char nombre[20];
	char estado[10];
	int tamano;
	char fecha[10];
	char hora[10];
}nuevaI;

void crear();
bool isEmpty(void);
bool isFull(void);
void agregar(void);
void eliminar(void);
void mostrar(void);

#endif