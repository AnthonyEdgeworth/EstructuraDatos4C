#ifndef _COLASCSRC_H 
#define _COLASCSRC_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void crear(void);
bool isEmpty(void);
bool isFull(void);
void agregar(void);
void eliminar(void);
void mostrar(void);

#endif