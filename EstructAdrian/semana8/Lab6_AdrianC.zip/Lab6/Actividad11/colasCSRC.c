#include "colasCSRC.h"

char *cola;
int frente;
int final;
int TamM;

void crear(void){
	cola = (char *)malloc(6 * sizeof(char));
	for(int i = 0; i<6; i++){//cola inicializada a 0
		cola[i] = 00;
	}
	final = 0;
	frente = 0;
	TamM = 6;
}

bool isEmpty(void){
	if(final == frente)
		return true;
	else
	return false;
	if(frente == TamM)
		frente = 0;
}

bool isFull(void){
	if(final - frente == TamM)
		return true;
	else{
		return false;
	}
	if(final == TamM)
		final = 0;
}

void agregar(void){
	char num;
	int tipo;
	if(isFull()){
		puts("ADVERTENCIA: Espacio insuficiente");
		puts("Desbordamiento de pila");
	}
	else{
		puts("Ingrese el nuevo caracter");
		scanf("%c", &num);
		getchar();
		
		puts("Por donde desea ingresar los datos");
		puts("1) Final");
		puts("2) Frente");
		scanf("%d", &tipo);
		getchar();
		
		if(tipo == 1){
			cola[final++] = num;
		}
		else
			cola[--frente] = num;
	}
}

void eliminar(void){
	int tipo;
	
	if(isEmpty()){
		puts("ADEVERTENCIA: No hay elementos");
		puts("Subdesbordamiento de pila");
	}
	else{
		puts("Por donde desea eliminar los datos");
		puts("1) Frente");
		puts("2) Final");
		scanf("%d", &tipo);
		getchar();
		
		if(tipo == 1)
			cola[frente++] = 00;
		else
			cola[--final] = 00;
	}
}

void mostrar(void){
	int i = frente;
	puts("La pila es: ");
	
	while(i > final){
		if(i<TamM){
			printf("%c ", cola[i++]);
		}
		else{
			i = 0;
		}
	}
	while(i < final){
		printf("%c ", cola[i++]);
	}
}