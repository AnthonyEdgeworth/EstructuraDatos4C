#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include "arbolBin.h"

#define SALIR 4

int menu(void);
void realizar(int opcion);

int main(int argc, char *argv[]){
	
	int opcion;
	do{
		opcion = menu();
		realizar(opcion);
	}while(SALIR != opcion);
	
	
	return 0;
}

int menu(void){
	int opcion;
	
	puts("Menu de acciones");
	puts("1) Crear nuevo arbol");
	puts("2) Imprimir arbol");
	puts("3) Informacion del arbol (funcion del examen)");
	puts("4) Salir");
	scanf("%d", &opcion);
	getchar();
	
	return opcion;
}

void realizar(int opcion){
	
	switch(opcion){
		case 1:
			tamano = 0;
			arbol = cargarNodos(arbol);
			break;
		case 2:
			puts("Inorden:");
			inorden(arbol);
			puts("");
			puts("Preorden:");
			preorden(arbol);
			puts("");
			puts("Postorden:");
			postorden(arbol);
			puts("");
			break;
		case 3:
			printf("Numero de nodos: %d\n", tamano);
			alturaTemp = -1;
			alturaFinal = -1;
			altura(arbol);
			printf("Altura del arbol: %d(La altura de un arbol no incluye el nivel raiz)\n", alturaFinal);
			break;
		case 4:
			break;
		default:
			puts("Opcion invalida");
			puts("Intente nuevamente");
	}
	
	puts("");
}