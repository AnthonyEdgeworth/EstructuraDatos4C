#include "arbolBin.h"

NodoA nuevoNodo(NodoA izq,char info ,NodoA der){
	NodoA q;
	q=(NodoA)malloc(sizeof(tiponodo));
	if(!q){
		printf("\nError al crear el nuevo nodo");
		return 0;
	}
	tamano++;
	q->info=info;
	q->izq=izq;
	q->der=der;
	return q;
}

NodoA cargarNodos(NodoA ini){
	char dato;
	char opc;
	printf("Dame el elemento del nodo a insertar\n");
	scanf("%c",&dato);
	ini=nuevoNodo(NULL,dato,NULL);
	fflush(stdin);
	
	printf("\nEl nodo %c tiene un subarbol Izquierdo?\n", dato);
	scanf("%c", &opc);
	getchar();
	
	fflush(stdin);
	if(opc=='s'|| opc=='S')
		ini->izq=cargarNodos(ini->izq);
	fflush(stdin);
	
	printf("\nEl nodo %c tiene subarbol derecho?\n",dato);
	scanf("%c",&opc);
	getchar();
		
	fflush(stdin);
	if(opc=='s'|| opc=='S')
		ini->der=cargarNodos(ini->der);
		
	return ini;
}

void inorden(NodoA raiz){
	if(raiz !=NULL){
		inorden(raiz->izq);
		printf("%c ",raiz->info);
		inorden(raiz->der);
	}
}

void preorden(NodoA raiz){
	if(raiz!=NULL){
		printf("%c ",raiz->info);
		preorden(raiz->izq);
		preorden(raiz->der);	
	}
}

void postorden(NodoA raiz){
	if(raiz!=NULL){
		postorden(raiz->izq);
		postorden(raiz->der);
		printf("%c ",raiz->info);
	}
}

void altura(NodoA raiz){
	alturaTemp++;
	
	if(raiz != NULL){
		if(alturaTemp > alturaFinal)
		alturaFinal = alturaTemp;
		
		if(raiz->izq != NULL)
			altura(raiz->izq);
			
		if(raiz->der != NULL)
			altura(raiz->der);
		else
			alturaTemp--;	
	} 
}