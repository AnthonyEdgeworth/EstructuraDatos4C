#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define max 100
/* laaboratorio 4 --ESRUCTURAS DE DATOS   3-A
EQUIPO : Adrian Fernado Cuevas Solis y Lesly Yocelyn Ovalle Santos

Actividad 7.- En equipo de dos personas hacer un programa en lenguaje C qué dada 
una expresión infija, prefija o posfija, haga las siguientes opciones.
a) Indique al usuario que tipo de expresión es ejemplo:
 5 3 + 2 / la expresión que se insertó está en notación posfija
b) Indique al usuario el resultado de la expresión en infija, posfija y prefija
 ejemplo: 5 3 + / 2 es 

		partes trabajadas:
		adrian 		todo (a)  la mitad de (b)--[donde se resuelve la ecuacion]
		lesly 		pseudocódigo y finalisa (b) [unir punto a,b y transforar infija prefija a posfija]*/

#define esOperador(x) x == '*' || x == '+' || x == '-' || x == '/' || x == '^' ? 1:0
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//variables globales
	char posfija[50];
	double pilasE[50]; //guarda los numeros a utilizar
	int TopeE = -1;
		
//funciones
	int operadorTipo(char a);//encuentra el tipo de operador
	int charInt(char a);//transforma el numero tipo char a int
	void operacion(int tipo);
	
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
char Pila [max];
int Tope  = -1;
char Simbolo;
char EPOS[max];
char expresion[max];

//para definir 
int tamano(char *cadena);
void punto1(int *tipo);


int i=0;
int j=0;
int prio(char opera, char operaPila);

int main(int argc, char *argv[]) {
	
	int tipoExp;
	puts("Ingresa la expresion");
	gets(expresion);
	punto1(&tipoExp);//encuentra, guarda y meciona el tipoExp de ecuacion
	
	while(expresion[i]!='\0'){///segun yo aqi esta lo que preguntas si esta baio el espacio
		Simbolo = expresion[i];
		if(Simbolo == '('){
			Tope++;
			Pila[Tope] = Simbolo;
		}//fin de if 22
		else{
			if(Simbolo == ')'){
				while(Pila[Tope]!='('){
					EPOS[j]=Pila[Tope];
					j++;
					Tope--;
				}//fin while 28
			Tope--;	
			}//fin if 27
			else{
				if(Simbolo!='+' && Simbolo!='-' && Simbolo!='*' && Simbolo!='/' && Simbolo!='%' && Simbolo!='^'){
					EPOS[j] = Simbolo;
					j++;
				}//fin if 36
				else{
					while(Tope >-1 && prio(Simbolo, Pila[Tope])<0){
						EPOS[j] = Pila[Tope];
						Tope--;
						j++;
					}//fin while 41
					Tope++;
					Pila[Tope] = Simbolo;
				}
			}
		}//fin else 26
	i++;
	}//fin de while 20
	
	while(Tope > -1){
		EPOS[j] = Pila[Tope];
		Tope--;
		j++;
	}//fin while 54

//---------------------------------------------------------

//	gets(posfija);
	int I = 0;
	
	int tipoOperacion;
	
	while(EPOS[I] != '\0'){
		if(esOperador(EPOS[I])){//si es operador
			tipoOperacion = operadorTipo(EPOS[I]);
			//usar los operadores (ten cuidado de limpiar la pilasE
//para que los resulatados de operaciones replacen a los numeros corresponidentes, hacerlos -1//checar bien, ya que no podemos recibir valores negativos
			operacion(tipoOperacion);
		}
		else{
			pilasE
	[++TopeE] = charInt(EPOS[I]);
		}
		I++;
	}
	
	printf("El resultado es %.2f", pilasE[TopeE]);
	
	return 0;
}//fin del main
//

//funciones de infija a posfija--
int prio(char opera, char operaPila){
	int p1=0;
	int p2=0;
	
	if(opera=='(' || opera==')'){p1=0;}
	
	if(opera=='+' || opera=='-'){p1=1;}
	
	if(opera=='/' || opera=='*' ){p1=2;}
	
	if(opera=='^'){p1=3;}
	//-----------
	if(operaPila=='(' || operaPila==')'){p2=0;}
	
	if(operaPila=='+' || operaPila=='-'){p2=1;}
	
	if(operaPila=='/' || operaPila=='*'){p2=2;}
	
	if(operaPila=='^'){p2=3;}
	
	return p1-p2;
}

int operadorTipo(char a){
	int tipo;
	switch(a){
		case '+':
			tipo = 1;
			break;
		case '-':
			tipo = 2;
			break;
		case '*':
			tipo = 3;
			break;
		case '/':
			tipo = 4;
			break;
		default://potencia
		tipo = 5;
	}
	return tipo;
}
//funciones para resultado de la ecuacion----
int charInt(char a){//de char a numero
	int numero;
	switch(a){
		case '0':
			numero = 0;
			break;
		case '1':
			numero = 1;
			break;
		case '2':
			numero = 2;
			break;
		case '3':
			numero = 3;
			break;
		case '4':
			numero = 4;
			break;
		case '5':
			numero = 5;
			break;
		case '6':
			numero = 6;
			break;
		case '7':
			numero = 7;
			 break;
		case '8':
			numero = 8;
			break;
		default://9
		numero = 9;
	}
	return numero;
}

void operacion(int tipo){
	double resultado;
	switch(tipo){
		case 1://suma
			resultado = pilasE
	[TopeE-1] + pilasE
	[TopeE];
			break;
		case 2://resta
			resultado = pilasE
	[TopeE-1] - pilasE
	[TopeE];
			break;
		case 3://multiplicacion
			resultado = pilasE
	[TopeE-1] * pilasE
	[TopeE];
			break;
		case 4://division
			resultado = pilasE
	[TopeE-1] / pilasE
	[TopeE];
			break;
		default://potencia
			resultado = pow(pilasE
	[TopeE-1] , pilasE
	[TopeE]);
	}
	pilasE[--TopeE] = resultado;
}

//funciones para el tipo de notacion ------
int tamano(char *cadena){
	int i = 0;
	while(cadena[i] != '\0'){
		i++;
	}
	return i;
}

void punto1(int *tipoExp){
		if(esOperador(expresion[0])){//si el primer caracter es un operador es prefija
		puts("La expresion que se inserto esta en notacion prefija");
		*tipoExp = 3;
	}
	else{
		if(esOperador(expresion[tamano(expresion)-1])){//si el ultimo caracter de la expreion es un operador es posfija
			puts("La expresion que se inserto esta en notacion posfija");
			*tipoExp = 2;
		}
		else{//si no es prefija ni posfija es infija
			puts("La expresion que se inserto esta en notacion infija");
			*tipoExp = 1;
		}
	}
}