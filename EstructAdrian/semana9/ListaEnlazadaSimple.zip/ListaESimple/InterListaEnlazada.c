#include "InterListaEnlazada.h"

nodo NuevoNodo(int elem, nodo liganueva){
	nodo n;
	n=(nodo)malloc(sizeof(tiponodo));
	if (!n){
		puts("Error el crear nodo nuevo!!");
		return NULL;
	}
	else{
		n->info=elem;
		n->liga=liganueva;
		return n;
	}
}
listaE CrearFinal(listaE lst,int Elem){
	if(EsVacia(lst)){
		lst.inicio=NuevoNodo(Elem,NULL);
		lst.fin=lst.inicio;
		lst.t++;
	}
	else{
		lst.fin->liga=NuevoNodo(Elem,NULL);
		lst.fin=lst.fin->liga;
		lst.t++;
	}
	//Recorrer(lst);
	return lst;
}

listaE CrearInicio(listaE prim, int elem){
		nodo t;
	if (EsVacia(prim)){
		prim.inicio= NuevoNodo(elem, NULL);
		prim.fin=prim.inicio;
		prim.t++;	
	}else{
		t=NuevoNodo(elem, NULL);
		t->liga=prim.inicio;
		prim.inicio=t;
		prim.t++;
	}
	//Recorrer(prim);
	return prim;
}

bool EsVacia(listaE lst){
	if (lst.inicio != NULL)
		return false;
	else
	return true;
}
void Recorrer(listaE lst){
	nodo t;
	if (EsVacia(lst)){
		printf("La lista esta vacia\n");
	} else {
		t = lst.inicio;
		printf("\nEstado Actual del TDA Lista Enlazada Sencilla\n");
		while(t != NULL) {
			printf("%d ->", t->info);
			t = t->liga;
		}
	}
}

nodo BuscarX(listaE lista, int ElemX, char Modo){
	nodo t = lista.inicio;
	nodo q = t;
	
	while(t != NULL){
		while(t != NULL){
			if(t->info == ElemX){
				if(Modo == 'A')
					return q;
				else
					return t;
			} else {
				q = t;
				t = t->liga;
			}
		}
	}
	return NULL;
}

listaE InsertarAntesX(listaE lst, int Elem, int ElemX){
	nodo x;
	if(EsVacia(lst))
		puts("Lista vacia");
	else{
		x = BuscarX(lst, ElemX, 'A');
		if(x != NULL){
			if(x == lst.inicio && x->info == ElemX)
				lst=CrearInicio(lst,Elem);
			else{
				x->liga = NuevoNodo(Elem,x->liga);
				lst.t++;
				Recorrer(lst);
			}
		} else{
			puts("");
			puts("Elemento no encontrado");
			//Recorrer(lst);
		}
	}
	return lst;
}

listaE InsertarDespuesX(listaE lst, int Elem, int ElemX){
	nodo x;
	if(EsVacia(lst))
		puts("Lista Vacia");
	else{
		x = BuscarX(lst,ElemX,'D');
		if(x!=NULL){
			if(x->liga==NULL)
				lst=CrearFinal(lst,Elem);
			else{
				x->liga=NuevoNodo(Elem,x->liga);
				lst.t++;
				//Recorrer(lst);
			}
		}
	}
}

listaE EliminarInicio(listaE lst){
	nodo aux;
	if(EsVacia(lst))
		puts("Es vacia");
	else{
		aux = lst.inicio;
		lst.inicio = aux->liga;
		free(aux);
	}
	//Recorrer(lst);
	return lst;
}

listaE EliminarFinal(listaE lst){
	nodo aux=lst.inicio;
	if(EsVacia(lst)){
		puts("Lista vacia");
	}else if(lst.inicio==lst.fin){
		lst.inicio=NULL;
		lst.fin=NULL;
		lst.t--;
		free(lst.inicio);
		free(lst.fin);
	}else{
		while((aux->liga!=NULL)&& (aux->liga!=lst.fin)){
		aux=aux->liga;
		}
		lst.fin=aux;
		aux=aux->liga;
		lst.fin->liga=NULL;
		
		lst.t--;
		free(aux);
	}
	//Recorrer(lst);
	return lst;
}

listaE EliminarX(listaE lst, int ElemX){
	nodo x, aux;
	if(EsVacia(lst))
		puts("Es vacia");
	else{
		x = BuscarX(lst, ElemX, 'A');
		if(x != NULL){
			if(x == lst.inicio && x->info == ElemX)
				lst = EliminarInicio(lst);
			else if(x->liga == lst.fin){
				lst = EliminarFinal(lst);
			}
			else{
				aux = x->liga;
				x->liga = aux->liga;
				lst.t--;
				free(aux);
			}
		}
	}
	//Recorrer(lst);
	return lst;
}

listaE EliminarAntesX(listaE lst, int ElemX){
	nodo x, aux;
	
	if(EsVacia(lst))
		puts("Es vacia");
	else{
		x = BuscarX(lst, ElemX, 'D');
		if(x != NULL){
			if(x == lst.inicio && x->info == ElemX)
				printf("No hay elementos antes de %d\n", ElemX);
			else{
				x = BuscarX(lst, ElemX, 'A');
				if(x != NULL){
					if(x == lst.inicio)
						lst = EliminarInicio(lst);
					else{
						aux = BuscarX(lst,x->info, 'A');
						aux->liga = x->liga;
						free(x);
					}
				}
			}
		}
	}
	//Recorrer(lst);
	return lst;
}

listaE EliminarDespuesX(listaE lst, int ElemX){
	nodo x, aux;
	if(EsVacia(lst))
		puts("Es vacia");
	else{
		x = BuscarX(lst, ElemX, 'D');
		if(x != NULL){
			if(x->liga==NULL)
				printf("No hay elementos despues de %d\n", ElemX);
			else{
				aux = x->liga;
				x->liga = aux->liga;
				free(aux);
			}
		}
	}
	//Recorrer(lst);
	return lst;
}

listaE EliminarDuplicados(listaE lst){
	nodo t;
	int x[50], y, max = 0, repetido = 0;
	
	if (EsVacia(lst)){
		printf("La lista esta vacia\n");
	} else {
		t = lst.inicio;
		while(t != NULL) {
			y = t->info;
			for(int i = 0; i < max; i++){
				if(y == x[i]){
					lst = EliminarX(lst, y);
					repetido = 1;
				}
			}
			if(repetido == 0){
				x[max++] = y;
			}
			
			repetido = 0;
			t = t->liga;
		}
	}
	return lst;
}

listaE OrdenarLista(listaE lst){
	nodo pivote = NULL;
	nodo actual = NULL;
	int tmp;
	
	if(EsVacia(lst))
		puts("La lista esta vacia");
	else{
		pivote = lst.inicio;
		while(pivote->liga!=NULL){
			actual = pivote->liga;
			while(actual != NULL){
				if(pivote->info > actual->info){
					tmp = pivote->info;
					pivote->info = actual->info;
					actual->info = tmp;
				}
				actual = actual->liga;
			}
			pivote = pivote->liga;
		}
	}
	
	return lst;
}