#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include "InterListaEnlazada.h"

void menu(void);

int main(int argc, char *argv[]) {
	int opcion, men=0, elem, x;
	do{
	puts("Que desea hacer?");
	menu();
	scanf("%d", &opcion);
	getchar();
	switch(opcion){
	case 1:
		printf("Ingrese el elemnto\n");
		scanf("%d", &elem);
		getchar();
		Lista = CrearFinal(Lista, elem);
		break;
	case 2:
		printf("Ingrese el elemento\n");
		scanf("%d", &elem);
		getchar();
		Lista = CrearInicio(Lista, elem);
		break;
	case 3:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		puts("Ingrese el numero a agregar");
		scanf("%d", &elem);
		getchar();
		
		Lista = InsertarAntesX(Lista, elem, x);
		break;
	case 4:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		puts("Ingrese el numero a agregar");
		scanf("%d", &elem);
		getchar();
		
		Lista = InsertarDespuesX(Lista, elem, x);
		break;
	case 5:
		puts("Ingrese el numero a eliminar");
		scanf("%d", &elem);
		getchar();
		Lista = EliminarX(Lista,elem);
		break;
	case 6:
		Lista = EliminarInicio(Lista);
		break;
	case 7:
		Lista = EliminarFinal(Lista);
		break;
	case 8:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		
		Lista = EliminarAntesX(Lista, x);
		break;
	case 9:
		puts("Ingrese el numero X");
		scanf("%d", &x);
		getchar();
		
		Lista = EliminarDespuesX(Lista, x);
		break;
	case 10:
		Lista = OrdenarLista(Lista);
		break;
	default:
		men=1;
	}
	Recorrer(Lista);
	puts("");
	}while(men==0);
	return 0;
}

void menu(void){
	puts("[1]Crear Final.");
	puts("[2]Crear Inicio.");
	puts("[3]Insertar antes de X.");
	puts("[4]Insertar despues de X");
	puts("[5]Eliminar X");
	puts("[6]Eliminar Inicio");
	puts("[7]Eliminar Final");
	puts("[8]Eliminar Antes de X");
	puts("[9]Eliminar Despues del X");
	puts("[10]Ordenar");
	puts("[11]Salir");
}