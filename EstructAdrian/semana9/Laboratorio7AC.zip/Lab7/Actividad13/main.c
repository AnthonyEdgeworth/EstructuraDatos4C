#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include <string.h>
#include "InterListaEnlazada.h"

void menu(void);

int main(int argc, char *argv[]) {
	int opcion, men=0, elem;
	char name[50];
	
	do{
	puts("Que desea hacer?");
	menu();
	scanf("%d", &opcion);
	getchar();
	switch(opcion){
	case 1:
		puts("NUEVO REGISTRO");
		puts("Titulo del libro:");
		gets(name);
		
		puts("Numero de Serie:");
		scanf("%d", &elem);
		getchar();
		
		Lista = CrearFinal(Lista, elem, name);
		break;
	case 2:
		Lista = EliminarFinal(Lista);
		break;
	default:
		men=1;
	}
	Recorrer(Lista);
	puts("");
	}while(men==0);
	return 0;
}

void menu(void){
	puts("[1]Aniadir");
	puts("[2]Eliminar");
	puts("[3]Salir");
}