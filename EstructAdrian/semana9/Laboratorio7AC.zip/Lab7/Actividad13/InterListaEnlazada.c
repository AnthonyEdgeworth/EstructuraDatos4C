#include "InterListaEnlazada.h"

nodo NuevoNodo(int elem, nodo liganueva, char *a){
	nodo n;
	n=(nodo)malloc(sizeof(tiponodo));
	if (!n){
		puts("Error el crear el nuevo registro!!");
		return NULL;
	}
	else{
		n->info=elem;
		strcpy(n->nombre, a);
		n->liga=liganueva;
		return n;
	}
}
listaE CrearFinal(listaE lst,int Elem, char *a){
	if(EsVacia(lst)){
		lst.inicio=NuevoNodo(Elem,NULL, a);
		lst.fin=lst.inicio;
		lst.t++;
	}
	else{
		lst.fin->liga=NuevoNodo(Elem,NULL, a);
		lst.fin=lst.fin->liga;
		lst.t++;
	}
	
	return lst;
}

bool EsVacia(listaE lst){
	if (lst.inicio != NULL)
		return false;
	else
	return true;
}
void Recorrer(listaE lst){
	nodo t;
	int x[50], i = 0;
	char a[50][50];
	
	if (EsVacia(lst)){
		printf("La libreria esta vacia\n");
	} else {
		t = lst.inicio;
		printf("\nEstado Actual de la libreria:\n\n");
		while(t != NULL) {
			x[i] = t->info;
			strcpy(a[i], t->nombre);
			i++;
			t = t->liga;
		}
		while(--i >= 0){
			puts("^");
			puts("|");
			printf("Titulo: %s\n", a[i]);
			printf("Numero de serie: %d\n", x[i]);
		}
	}
}

listaE EliminarFinal(listaE lst){
	nodo aux=lst.inicio;
	if(EsVacia(lst)){
		puts("La libreria esta vacia");
	}else if(lst.inicio==lst.fin){
		lst.inicio=NULL;
		lst.fin=NULL;
		lst.t--;
		free(lst.inicio);
		free(lst.fin);
	}else{
		while((aux->liga!=NULL)&& (aux->liga!=lst.fin)){
		aux=aux->liga;
		}
		lst.fin=aux;
		aux=aux->liga;
		lst.fin->liga=NULL;
		
		lst.t--;
		free(aux);
	}
	
	return lst;
}