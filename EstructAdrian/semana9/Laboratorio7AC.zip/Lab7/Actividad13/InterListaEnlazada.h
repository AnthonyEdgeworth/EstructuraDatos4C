#include <stdlib.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

 typedef struct Nodos{
	int info;
	char nombre[50];
	struct Nodos *liga;
}tiponodo;
typedef struct lista{
	struct Nodos *inicio;
	struct Nodos *fin;
	int t;
}tipolista;
typedef tiponodo *nodo;
typedef tipolista listaE;
listaE Lista;
nodo NuevoNodo(int,nodo, char*);
listaE CrearFinal(listaE,int, char*);
bool EsVacia(listaE);
void Recorrer(listaE);

int tsize(listaE);

listaE EliminarFinal(listaE);