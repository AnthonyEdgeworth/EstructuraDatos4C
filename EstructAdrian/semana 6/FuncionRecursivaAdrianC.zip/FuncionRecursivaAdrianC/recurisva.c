#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

unsigned long int recursiva(int *vecesRestantes);

int main(int argc, char *argv[]) {
	int n;
	
	puts("Ingrese el valor de la x");
	scanf("%d", &n);
	
	double time = 0.0;
	clock_t begin = clock();
	
	printf("%lu\n", recursiva(&n));
	
	clock_t end = clock();
	
	time += (double)(end-begin) / CLOCKS_PER_SEC;
	
	printf("Time: %f", time);
	return 0;
}

unsigned long int recursiva(int *vecesRestantes){
	if(*vecesRestantes == 0){
		return 0;
	}else{
		int x = *vecesRestantes - 1;
		return(2*recursiva(&x)+ (*vecesRestantes)*(*vecesRestantes));//puesto por un bug en la potencia
	}
	
}