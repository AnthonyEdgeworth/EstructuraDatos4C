#include <stdio.h>
#define maxi 5
#define max 100

int i;
void hanoi(int, char[max], char[max], char[max], int [maxi], int[maxi], int [maxi]);
int main(int argc, char *argv[]) {
	int n;
	int ori[maxi]={1,2,3,4,5}, des[maxi], aux[maxi];
	char o[max]="Origen";
	char d[max]="Destino";
	char a[max]="Auxiliar";
	printf("Ingrese el numero de discos\n");
	scanf("%d", &n);
	hanoi(n, o, d, a, ori, des, aux);
	for(int j=0;j<n;j++){
		printf("%d, ", des[j]);
	}
	printf("Total de movimientos: %d", i);
	return 0;
}


void hanoi(int n, char o[max], char d[max], char a[max], int ori[maxi], int des[maxi], int aux[maxi]){
	if(n==1){
		i++;
		printf("%s  -> \t %s\n", o, d);
		des[n-1]=ori[n-1];
	}else{
		hanoi(n-1, o, a, d, ori, aux, des);
		printf("%s  -> \t %s\n", o, d);
		des[n-1]=ori[n-1];
		hanoi(n-1,a,d,o, aux, des, ori);
		
		i++;
	}
}
