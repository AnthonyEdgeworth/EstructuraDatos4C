#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void f(int num, int div);

int main(int argc, char *argv[]) {
	
	double time = 0.0;
	clock_t begin = clock();

	f(25,2);
	
	clock_t end = clock();
	
	time += (double)(end-begin) / CLOCKS_PER_SEC;
	
	printf("Time: %f", time);
	
	return 0;
}

void f(int num, int div) {
	if (num>1) {
		if ((num%div) == 0){ 
 			printf("%d\n", div);
 			f(num/div,div); 
		} else { 
			f(num,div+1); 
		}
	}
}