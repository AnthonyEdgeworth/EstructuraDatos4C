#include <stdlib.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>
#include <stdio.h>
 
 typedef struct Nodos{
	int info;
	struct Nodos *liga;
}tiponodo;
typedef struct lista{
	struct Nodos *inicio;
	struct Nodos *fin;
	int t;
}tipolista;

int tamanoL;

typedef tiponodo *nodo;
typedef tipolista listaE;
listaE Lista;
nodo NuevoNodoF(int, nodo, listaE);
nodo NuevoNodo(int, nodo, listaE);
listaE CrearFinal(listaE,int);
bool EsVacia(listaE);
void Recorrer(listaE);

listaE CrearInicio(listaE,int);
nodo BuscarX(listaE Lista, int,char);
listaE InsertarAntesX(listaE,int,int);
listaE InsertarDespuesX(listaE,int, int);
listaE EliminarX(listaE, int);

int tsize(listaE);
listaE EliminarAntesX(listaE, int);
listaE EliminarDespuesX(listaE, int);
listaE EliminarInicio(listaE);
listaE EliminarFinal(listaE);
listaE OrdenarLista(listaE);
listaE EliminarDuplicados(listaE);