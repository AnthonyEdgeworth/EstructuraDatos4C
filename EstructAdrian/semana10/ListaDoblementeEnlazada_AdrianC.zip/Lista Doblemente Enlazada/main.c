#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "ListaDE.h"

#define NO 9

void menu(void);
void realizar(int opcion);

int main(int argc, char *argv[]){
	int opcion;

	do{
		menu();
		
		scanf("%d", &opcion);
		getchar();
		
		realizar(opcion);
		
		Recorrer(Lista);
		puts("");
	}while(opcion != NO);

	return 0;
}

void menu(void){
	puts("Menu de acciones");
	puts("1) Aniadir Final");
	puts("2) Aniadir Inicio");
	puts("3) Insertar Antes de X");
	puts("4) Insertar Depues de X");
	puts("5) Eliminar X");
	puts("6) Eliminar inicio");
	puts("7) Eliminar Final");
	puts("8) Eliminar antes de X");
	puts("9) Salir");
}

void realizar(int opcion){
	int n;
	int X;
		
	switch(opcion){
		case 1:
			puts("Ingrese el numero:");
			scanf("%d", &n);
			getchar();
			
			Lista = CrearFinal(Lista, n);
			break;
		case 2:
			puts("Ingrese el numero");
			scanf("%d", &n);
			getchar();
			
			Lista = CrearInicio(Lista, n);
			break;
		case 3:
			puts("Ingrese el numero X");
			scanf("%d", &X);
			getchar();
			
			puts("Ingrese el numero");
			scanf("%d", &n);
			getchar();
			
			Lista = InsertarAntesX(Lista, n, X);
			break;
		case 4:
			puts("Ingrese el numero X");
			scanf("%d", &X);
			getchar();
			
			puts("Ingrese el numero");
			scanf("%d", &n);
			getchar();
			
			Lista = InsertarDespuesX(Lista, n, X);
			break;
		case 5:
			puts("Ingrese el numero");
			scanf("%d", &n);
			getchar();
			
			Lista = EliminarX(Lista, n);
			break;
		case 6:
			Lista = EliminarInicio(Lista);
			break;
		case 7:
			Lista = EliminarFinal(Lista);
			break;
		case 8:
			puts("Ingrese el numero X");
			scanf("%d", &X);
			getchar();
			
			Lista = EliminarAntesX(Lista, X);
			break;
		case 9:
			break;
		default:
			puts("Error: Opcion Invalida");
	}
}