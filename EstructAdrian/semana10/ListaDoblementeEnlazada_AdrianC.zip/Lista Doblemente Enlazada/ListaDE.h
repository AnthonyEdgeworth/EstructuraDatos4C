#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct nodoD{
	int info;
	struct nodoD *ligaizq;
	struct nodoD *ligader;
}tiponodo;

typedef struct lista{
	struct nodoD *inicio;
	struct nodoD *fin;
	int t;
}tipolista;



typedef tiponodo *nodoD;
typedef tipolista listaED;
listaED Lista;

listaED EliminarInicio(listaED lst);
nodoD NuevoNodo(int, nodoD, nodoD);
bool EsVacia(listaED);
listaED CrearFinal(listaED, int);
listaED CrearInicio(listaED, int);
listaED InsertarAntesX(listaED, int, int);
listaED InsertarDespuesX(listaED, int, int);
nodoD BuscarX(listaED, int, char);
listaED EliminarX(listaED, int);
listaED EliminarFinal(listaED);
listaED EliminarInicio(listaED);
listaED EliminarAntesX(listaED, int);
void Recorrer(listaED);
int tsize(listaED);
void Recorrerizq(listaED);
listaED Ordenar(listaED);