#include "ListaDE.h"

nodoD NuevoNodo(int elem,nodoD ligaizq,nodoD ligader)
{
	nodoD n;
	n = (nodoD)malloc(sizeof(tiponodo));
	if(!n)
	{
		printf("Error al crear nodo nuevo!!");
		return NULL;
	}
	else
	{
		n->info=elem;
		n->ligaizq=ligaizq;
		n->ligader=ligader;
		return  n;
	}
}

bool EsVacia(listaED lst)
{
	if(lst.inicio!=NULL)
	return false;
	else
	return true;
}

listaED CrearFinal(listaED lst,int Elem)
{
	nodoD t;
	if(EsVacia(lst))
	{
		lst.inicio=NuevoNodo(Elem, NULL,NULL);
		lst.fin=lst.inicio;
		lst.t++;
	}
	else
	{
		t=NuevoNodo(Elem, NULL,NULL);
		lst.fin->ligader=t;
		t->ligaizq=lst.fin;
		lst.fin=t;
	}
	return lst;
}

listaED CrearInicio(listaED lst,int Elem)
{
	nodoD t;
	if(EsVacia(lst))
	{
		lst.inicio=NuevoNodo(Elem,NULL,NULL);
		lst.fin=lst.inicio;
		lst.t++;
	}
	else
	{
		t=NuevoNodo(Elem,NULL,lst.inicio);
		lst.inicio->ligaizq=t;
		lst.inicio=t;
		lst.t++;
	}
	return lst;
}

void Recorrer(listaED lst)
{
	nodoD t;
	if(EsVacia(lst))
	{
		
		printf("\nLa lista esta vacia\n");
		
	}
	else{
		t=lst.inicio;
		printf("\nEstado Actual del TDA Lista Enlazada Doble:\n");
		while(t !=NULL)
		{
			printf("[%d]--> ", t->info);
			t=t->ligader;
		}
	}
}

nodoD BuscarX(listaED lst, int ElemX, char Modo)
{
	nodoD t=lst.inicio;
	while(t!=NULL)
	{
	 if(t->info==ElemX)
	 {
	
		if(Modo=='A')
		{
		    return t->ligaizq;
     	}
	 	else
	 	{
	 		return t;
		}
	 }
	 else
	 {
	 	t=t->ligader;
	 }
   }
   return NULL;
}

listaED InsertarAntesX(listaED lst ,int Elem,int ElemX)
{
	nodoD x;
	nodoD t;
	if(EsVacia(lst))
	{
		printf("Lista vacia");
	}
	else
	{
		x =BuscarX(lst,ElemX,'D');
		if(x!=NULL)
		{
		
		if(x==lst.inicio && x->info==ElemX)
		lst=CrearInicio(lst,Elem);
		else
		{
			t=NuevoNodo(Elem,x->ligaizq,x);
			x->ligaizq=t;
			x=t->ligaizq;
			x->ligader=t;
			lst.t++;
		}
		
	    }
	    else
	    {
	    	printf("\nElemento no encotrado\n");
		}
	}

}

listaED InsertarDespuesX(listaED lst ,int Elem,int ElemX)
{
	nodoD x;
	nodoD t;
	if(EsVacia(lst))
	{
		printf("Lista vacia");
	}
	else
	{
		x=BuscarX(lst,ElemX,'D');
		if(x!=NULL)
		{
			if(x==lst.fin)
			{
				lst=CrearFinal(lst,Elem);
			}
			else
			{
				t=NuevoNodo(Elem,x,x->ligader);
				x->ligader=t;
				x=t->ligader;
				x->ligaizq=t;
				
				lst.t++;
			}
		}
	}
	return lst;
}

void Recorrerizq(listaED lst)
{
	nodoD t;
	if(EsVacia(lst))
	{
		printf("\nLa lista es vacia\n");
	}
	else
	{
		t=lst.fin;
		printf("\nEstado Actual del TDA Lista Enlazada Doble:\n");
		while(t!=NULL)
		{
			printf("%d->",t->info);
			t=t->ligaizq;
		}
	}
}

listaED EliminarX(listaED lst ,int ElemX)
{
	nodoD x,aux;
	if(EsVacia(lst))
	{
		//printf("Lista vacia");
	}
	else
	{
		x=BuscarX(lst,ElemX,'D');
		if(x!=NULL) 
		{
			if(x==lst.inicio && x->info==ElemX)
			{
				lst=EliminarInicio(lst);
			}
			else if(x==lst.fin)
			{
				lst=EliminarFinal(lst);
			}
			else
			{
				aux=x->ligaizq;
				aux->ligader=x->ligader;
				aux=x->ligader;
				aux->ligaizq=x->ligaizq;
				lst.t++;
				free(x);
				Recorrer(lst);
				Recorrerizq(lst);
			}
		}
		else
		{
			printf("\nElemento no encontrado\n");
		}
   }
   return lst;
}

listaED EliminarInicio(listaED lst) {
	nodoD aux;
	if(EsVacia(lst))
	{
		//printf("Lista vacia");
	}
	else
	{
		if(lst.inicio==lst.fin)
		{
			lst.inicio=lst.fin=NULL;
			lst.t--;
			free(lst.inicio);
			free(lst.fin);
		}
		else
		{
			aux=lst.inicio;
			lst.inicio=aux->ligader;
			lst.inicio->ligaizq=NULL;
			lst.t--;
			free(aux);
		}
	}
	return lst;
}

listaED EliminarFinal(listaED lst)
{
	nodoD aux;
	if(EsVacia(lst))
	{
		//printf("Lista vacia");
	}
	else
	{
		if(lst.inicio==lst.fin)
		{
			lst.inicio=lst.fin=NULL;
			lst.t--;
			free(lst.inicio);
			free(lst.fin);
		}
		else
		{
			aux=lst.fin;
			lst.fin=aux->ligader;
			lst.fin->ligader=NULL;
			lst.t--;
			free(aux);
		}
	}
	Recorrer(lst);
	Recorrerizq(lst);
	return lst;
	
}

listaED EliminarAntesX(listaED lst,int ElemX){
	nodoD x,aux;
	if(EsVacia(lst))
		printf("Lista vacia");
	
	else{
		x=BuscarX(lst,ElemX,'D');
		if(x!=NULL){
			if(x==lst.inicio && x->info==ElemX)
			printf("No hay elementos antes de %d",ElemX);
		  else{
		 	  aux=x->ligaizq;
			  if(aux=lst.inicio){
				lst=EliminarInicio(lst);
			  }
			  else{
				 x=aux->ligaizq;
				 x->ligader=aux->ligader;
				 lst.t--;
				 free(aux);
			  }
		  }
	}
	else{
			printf("\nElemento no encontradp\n");
		}
 }
 
 return lst;
	
}