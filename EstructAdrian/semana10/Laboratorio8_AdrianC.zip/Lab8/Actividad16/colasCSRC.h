#ifndef _COLASCSRC_H 
#define _COLASCSRC_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void crear(void);
bool isEmpty(void);
bool isFull(void);

void meter(char x);
char sacar();
void inyectar(char x);
char eyectar();

void mostrar(void);

#endif