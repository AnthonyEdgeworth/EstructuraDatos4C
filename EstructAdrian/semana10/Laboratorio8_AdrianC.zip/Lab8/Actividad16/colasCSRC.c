#include "colasCSRC.h"

char *cola;
int frente;
int final;
int TamM;

void crear(void){
	cola = (char *)malloc(20 * sizeof(char));
	for(int i = 0; i<20; i++){//cola inicializada a 0
		cola[i] = 00;
	}
	final = 0;
	frente = 0;
	TamM = 20;
}

bool isEmpty(void){
	if(final == frente)
		return true;
	else
	return false;
	if(frente == TamM)
		frente = 0;
}

bool isFull(void){
	if(final - frente == TamM)
		return true;
	else{
		return false;
	}
	if(final == TamM)
		final = 0;
}

void meter(char x){
	if(isFull()){
		puts("ADVERTENCIA: Espacio insuficiente");
		puts("Desbordamiento de cola");
	}
	else{
			cola[--frente] = x;
	}
}

char sacar(){
	char n = 00;
	if(isEmpty()){
		puts("ADEVERTENCIA: No hay elementos");
		puts("Subdesbordamiento de cola");
	}
	else{
			cola[frente++] = 00;
			n = cola[frente];
	}
	return n;
}

void inyectar(char x){
	if(isFull()){
		puts("ADVERTENCIA: Espacio insuficiente");
		puts("Desbordamiento de cola");
	}
	else{
			cola[final++] = x;
	}
}

char eyectar(){
	char n;
	if(isEmpty()){
		puts("ADEVERTENCIA: No hay elementos");
		puts("Subdesbordamiento de cola");
	}
	else{
			cola[--final] = 00;
			n = cola[final];
	}
	return n;
}

void mostrar(void){
	int i = frente;
	puts("La cola es: ");
	
	while(i > final){
		if(i<TamM){
			printf("%c <- ", cola[i++]);
		}
		else{
			i = 0;
		}
	}
	while(i < final){
		printf("%c <- ", cola[i++]);
	}
}