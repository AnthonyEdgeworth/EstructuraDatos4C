#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "colasCSRC.h"

void menu(void);
void realizar(int opcion);

int main(int argc, char *argv[]){
	int tamano;
	int opcion;
	
	puts("Caracteristicas");
	puts("La cola es de tipo char");
	puts("Las funciones no recibem cola pues la deberian de retornar y no se puede retornar junto a un int");
	puts("Cola es global");
	puts("");
	
	crear();
	do{
		menu();
		scanf("%d", &opcion);
		getchar();
		realizar(opcion);
		mostrar();
		puts("");
		puts("");
	}while(opcion != 5);
}

void menu(void){
	puts("Menu de acciones");
	puts("1) Meter al inicio");
	puts("2) Sacar al inicio");
	puts("3) Inyectar al final");
	puts("4) Eyectar al final");
}

void realizar(int opcion){
	char num;
	switch(opcion){
		case 1:
			puts("Ingrese el nuevo caracter");
			scanf("%c", &num);
			getchar();
			
			meter(num);
			break;
		case 2:
			printf("El elemento al frente es %c\n", sacar());
			break;
		case 3:
			puts("Ingrese el nuevo caracter");
			scanf("%c", &num);
			getchar();
			
			inyectar(num);
			break;
		case 4:
			printf("El elemento al final es %c\n", eyectar());
			break;
		case 5:
			break;
		default:
			puts("Opcion invalida");
			puts("Intente nuevamente");
	}
}