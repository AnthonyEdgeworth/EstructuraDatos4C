#include "ListaEnlazadaPila.h"

nodo NuevoNodo(int elem, nodo liganueva){
	nodo n;
	n=(nodo)malloc(sizeof(tiponodo));
	if(!n){
		puts("Error al crear un nuevo nodo");
		return NULL;
	}else{
		n->info=elem;
		n->liga=liganueva;
		return n;
	}
}

nodo BuscarX(listaE lista, int elemX, char modo){
	nodo t=lista.inicio;
	nodo q=t;
	while(t!=NULL){
		if(t->info==elemX){
			if(modo=='A'){
				return q;
			}else{
				return t;
			}
		}else{
		q=t;
		t=t->liga;
	}
	}
	return NULL;
}
		
listaE EnColar(listaE lst, int elem){
	if(EsVacia(lst)){
		lst.inicio=NuevoNodo(elem, NULL);
		lst.fin=lst.inicio;
		lst.t++;
	}else{
		lst.fin->liga=NuevoNodo(elem, NULL);
		lst.fin=lst.fin->liga;
		lst.t++;
	}
	return lst;
}
	
listaE Insertar(listaE lst){
	nodo aux=lst.inicio;
	if(EsVacia(lst)){
	}else if(lst.inicio==lst.fin){
		lst.inicio=NULL;
		lst.fin=NULL;
		lst.t--;
		free(lst.inicio);
		free(lst.fin);
	}else{
		while((aux->liga!=NULL)&& (aux->liga!=lst.fin)){
			aux=aux->liga;
		}
		lst.fin=aux;
		aux=aux->liga;
		lst.fin->liga=NULL;
		
		lst.t--;
		free(aux);
	}
	return lst;
}
	
int Insertarinfo(listaE lst){
	nodo t;
	t=lst.fin;
	return t->info;
}

bool EsVacia(listaE lst){
	if(lst.inicio!=NULL){
		return false;
	}else{
		return true;
	}
}
	
void Recorrer(listaE lst){
	nodo t;
	if(EsVacia(lst)){
		puts("La lista esta vacia");
	}else{
		t=lst.inicio;
		puts("Estado actual de la cola:\n");
		while(t!=NULL){
			printf("[%d] <-", t->info);
			t=t->liga;
		}
	}
}
	
listaE DesenColar(listaE lst){
	int count=0;
	nodo x;
	x=lst.inicio;
	while(x->liga!=NULL){
		pila1=EnColar(pila1, Insertarinfo(lst));
		lst=Insertar(lst);
		count++;
	}
	lst=Insertar(lst);
	for(int i=0;i<count;i++){
		lst=EnColar(lst, Insertarinfo(pila1));
		pila1=Insertar(pila1);
	}
	return lst;
}