#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

typedef struct nodos{	
	int info;
	struct nodos *liga;
}tiponodo;

typedef struct lista{
	struct nodos *inicio;
	struct nodos *fin;
	int t;
}tipolista;

typedef tiponodo *nodo;
typedef tipolista listaE;
listaE pila1, pila2, ColaL;

nodo BuscarX(listaE, int, char);
nodo NuevoNodo(int, nodo);
bool EsVacia(listaE);
void Recorrer(listaE);
listaE EnColar(listaE, int);
listaE Insertar(listaE);

listaE DesenColar(listaE);