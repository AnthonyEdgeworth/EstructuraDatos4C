#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdbool.h>

#include "ListaEnlazadaPila.h"

#define NO 3

void menu(void);
void realizar(int opcion);

int main(int argc, char *argv[]) {
	int opcion;
	do{
		menu();
		scanf("%d", &opcion);
		getchar();
		
		realizar(opcion);
		
		Recorrer(ColaL);
		puts("");
	} while(opcion != NO);
	return 0;
}

void menu(void){
	puts("Menu de acciones");
	puts("1) Encolar");
	puts("2) Desencolar");
	puts("3) Salir");
}

void realizar(int opcion){
	int num;
	
	switch(opcion){
		case 1:
			puts("Ingrese el numero");
			scanf("%d", &num);
			getchar();
			
			ColaL = EnColar(ColaL, num);
			break;
		case 2:
			ColaL = DesenColar(ColaL);
			break;
		case 3:
			break;
		default:
			puts("OPCION INVALIDA: Intentelo nuevamente");
		}
}