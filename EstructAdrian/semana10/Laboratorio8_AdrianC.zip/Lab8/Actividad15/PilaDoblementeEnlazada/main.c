#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "ListaDE.h"

#define NO 3

void menu(void);
void realizar(int opcion, int pila);
int tipoPila(void);
void imprimirPila(void);

int main(int argc, char *argv[]){
	tam1 = 0;
	tam2 = 0;
	
	int opcion;
	int pilaS;

	do{
		pilaS = tipoPila();
		menu();
		
		scanf("%d", &opcion);
		getchar();
		
		realizar(opcion, pilaS);
		
		imprimirPila();
		puts("");
	}while(opcion != NO);

	return 0;
}

void menu(void){
	puts("Menu de acciones");
	puts("1) Aniadir");
	puts("2) Eliminar");
	puts("3) Salir");
}

void realizar(int opcion, int pila){
	int n;
	int X;
		
	switch(opcion){
		case 1:
			puts("Ingrese el numero:");
			scanf("%d", &n);
			getchar();
			
			if(pila == 2)
				Lista = CrearFinal(Lista, n);
			else
				Lista = CrearInicio(Lista, n);	
			break;
		case 2:
			if(pila == 2)
				Lista = EliminarFinal(Lista);
			else
				Lista = EliminarInicio(Lista);	
			break;
		case 3:
			break;
		default:
			puts("Error: Opcion Invalida");
	}
}

int tipoPila(void){
	int x;
	
	puts("Que pila desea manejar");
	puts("1) Pila 1");
	puts("2) Pila 2");
	scanf("%d", &x);
	getchar();
	
	return x;
}

void imprimirPila(void){
	int tipo;
	
	puts("Que pila desea observar");
	puts("1) Pila 1");
	puts("2) Pila 2");
	puts("3) Ambas pilas");
	scanf("%d", &tipo);
	getchar();
	
	switch(tipo){
		case 1:
			Recorrer(Lista);
			break;
		case 2:
			Recorrerizq(Lista);
			break;
		case 3:
			Recorrer(Lista);
			
			Recorrerizq(Lista);
			break;
		default:
			puts("Opcion invalida");
			puts("Intente nuevamente");
	}
}