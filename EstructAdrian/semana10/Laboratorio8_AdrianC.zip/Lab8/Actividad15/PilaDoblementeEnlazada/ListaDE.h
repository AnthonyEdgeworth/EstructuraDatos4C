#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct nodoD{
	int info;
	struct nodoD *ligaizq;
	struct nodoD *ligader;
}tiponodo;

typedef struct lista{
	struct nodoD *inicio;
	struct nodoD *fin;
	int t;
}tipolista;


int tam1, tam2;

typedef tiponodo *nodoD;
typedef tipolista listaED;
listaED Lista;

listaED EliminarInicio(listaED lst);
nodoD NuevoNodo(int, nodoD, nodoD);
bool EsVacia(listaED);
listaED CrearFinal(listaED, int);
listaED CrearInicio(listaED, int);
listaED EliminarFinal(listaED);
listaED EliminarInicio(listaED);

void Recorrer(listaED);
int tsize(listaED);
void Recorrerizq(listaED lst);