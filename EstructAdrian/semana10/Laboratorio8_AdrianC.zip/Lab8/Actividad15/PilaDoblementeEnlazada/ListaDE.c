#include "ListaDE.h"

nodoD NuevoNodo(int elem,nodoD ligaizq,nodoD ligader)
{
	nodoD n;
	n = (nodoD)malloc(sizeof(tiponodo));
	if(!n)
	{
		printf("Error al crear nodo nuevo!!");
		return NULL;
	}
	else
	{
		n->info=elem;
		n->ligaizq=ligaizq;
		n->ligader=ligader;
		return  n;
	}
}

bool EsVacia(listaED lst)
{
	if(lst.inicio!=NULL)
	return false;
	else
	return true;
}

listaED CrearFinal(listaED lst,int Elem)
{
	nodoD t;
	if(EsVacia(lst))
	{
		lst.inicio=NuevoNodo(Elem, NULL,NULL);
		lst.fin=lst.inicio;
		lst.t++;
	}
	else
	{
		t=NuevoNodo(Elem, NULL,NULL);
		lst.fin->ligader=t;
		t->ligaizq=lst.fin;
		lst.fin=t;
		
		tam2++;
	}
	return lst;
}

listaED CrearInicio(listaED lst,int Elem)
{
	nodoD t;
	if(EsVacia(lst))
	{
		lst.inicio=NuevoNodo(Elem,NULL,NULL);
		lst.fin=lst.inicio;
		lst.t++;
	}
	else
	{
		t=NuevoNodo(Elem,NULL,lst.inicio);
		lst.inicio->ligaizq=t;
		lst.inicio=t;
		lst.t++;
		
		tam1++;
	}
	return lst;
}

void Recorrer(listaED lst)
{
	nodoD t;
	if(EsVacia(lst))
	{
		
		printf("\nLa pila 1 esta vacia\n");
		
	}
	else{
		int l = 0;
		t=lst.inicio;
		printf("\nEstado Actual de la primera pila:\n");
		while(t !=NULL && l <= tam1)
		{
			printf("%d-> ", t->info);
			t=t->ligader;
			l++;
		}
	}
}

listaED EliminarInicio(listaED lst) {
	nodoD aux;
	if(EsVacia(lst)  || tam1 < 0){	
		puts("La pila esta vacia, no se pueden eliminar elementos");
	}
	else
	{
		if(lst.inicio==lst.fin)
		{
			lst.inicio=lst.fin=NULL;
			lst.t--;
			free(lst.inicio);
			free(lst.fin);
		}
		else
		{
			aux=lst.inicio;
			lst.inicio=aux->ligader;
			lst.inicio->ligaizq=NULL;
			lst.t--;
			free(aux);
			
			tam1--;
		}
	}
	return lst;
}

listaED EliminarFinal(listaED lst)
{
	nodoD aux;
	if(EsVacia(lst) || tam2 < 0){
		puts("La pila esta vacia, no se pueden eliminar elementos");
	}
	else
	{
		if(lst.inicio==lst.fin)
		{
			lst.inicio=lst.fin=NULL;
			lst.t--;
			free(lst.inicio);
			free(lst.fin);
		}
		else
		{
			aux=lst.fin;
			lst.fin=aux->ligader;
			lst.fin->ligader=NULL;
			lst.t--;
			free(aux);
			
			tam2--;
		}
	}
	Recorrer(lst);
	Recorrerizq(lst);
	return lst;
	
}

void Recorrerizq(listaED lst){
	nodoD t;
	if(EsVacia(lst))
	{
		printf("\nLa pila 2 esta vacia\n");
	}
	else
	{
		int l = 0;
		
		t=lst.fin;
		printf("\nEstado de la segunda pila:\n");
		while(t!=NULL && l < tam2){
			printf("%d->",t->info);
			t=t->ligaizq;
			l++;
		}
	}
}