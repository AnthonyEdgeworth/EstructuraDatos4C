//librería que define la interfase del SumaSubsecMax
// usa librerías pero puede usarse una class de c++ o java
//nombre InterSumaSubsecMax.h

int a[6]={-2,11,-4,13,-5,2};
int secIni=0;
int secFin=0;
void leer();
int sumar(int*);
void imprimir(int*);

